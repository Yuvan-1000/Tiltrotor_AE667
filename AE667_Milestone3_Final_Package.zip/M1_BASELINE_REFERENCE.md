# Milestone-1 baseline retained for Milestone-2

`bemt_solver.py` in this package is the exact Milestone-1 `bemt_solver.py` from the submitted package. It is retained because M2 Section 3.1 explicitly requires the new edgewise model to recover the M1 hover and axial-flow limiting cases.

The file hash was checked before packaging; it is not modified by the M2 drivers. The regression reference values are in `data/m1_regression_expected.csv`.
