# M2 Model Limitations

The following limits are deliberate and are relevant when interpreting numerical results:

1. The edgewise rotor uses a rigid-disk approximation with no blade flapping. Cyclic pitch therefore appears directly as an azimuthal blade loading variation and hub moment rather than being filtered by flapping dynamics.
2. Reverse-flow elements are detected from U_T<0 and excluded from the forward-flow airfoil-load integration. They are not modeled with a reverse-flow polar.
3. The rotor airfoil uses the supplied linear/parabolic `Cl/Cd` model and an adopted |α|=12° stall flag. The polar is not a post-stall model.
4. Advancing-tip Mach is explicitly checked against M_adv=0.72, but no full compressibility/transonic correction is applied to the linear polar.
5. Rotor wake contraction, swirl recovery, blade-vortex interaction and rotor/wing interference are not modeled.
6. The aircraft aero model is steady and low-order: wing, horizontal tail, vertical tail and equivalent fuselage/nacelle parasite drag are represented. Sideslip and dynamic/control-surface aerodynamics are not resolved.
7. The conversion corridor is a dense candidate-control map seeded from the required 3×3 trim matrix, not hundreds of independent nonlinear trim solves. The map is labeled accordingly.
8. The transition mission is a scheduled demonstration, not a 6-DOF time-domain flight-dynamics simulation.
