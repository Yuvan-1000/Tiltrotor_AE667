# Milestone 2 run summary

This file records the main numerical checks from the final package run. All values are generated from the packaged task drivers using the common `aircraft_config.py` configuration.

## Task 3 — M1 limiting-case recovery

- Hover: 750 RPM, θ0=14°, h=0 m, Vaxial=0 m/s, Vedge=0, zero cyclic.
- Axial forward case: 650 RPM, θ0=30°, h=3000 m, Vaxial=30 m/s, Vedge=0, zero cyclic.

Both cases recover the unchanged M1 axial BEMT results to floating-point tolerance. The detailed numbers are in `outputs/task3_1_limiting_case_recovery.csv`.

## Task 4 — rotor/body/CG loads

The representative twin-rotor cases are:

- Helicopter-like: γ=90°, V=20 m/s, 750 RPM, h=500 m, ISA, θ0=14°.
- Intermediate conversion: γ=45°, V=10 m/s, 750 RPM, h=500 m, ISA, θ0=14°.

The two rotors use opposite rotation signs. Their steady shaft reaction yaw torques cancel in the symmetric aircraft load calculation. See `outputs/task4_twin_rotor_loads.csv` and `figures/task4_counter_rotation_torque.png`.

## Task 5 — control-response demonstrations

Both required operating conditions were run. The course cyclic convention used throughout is θ1c = lateral cyclic and θ1s = longitudinal cyclic. The CSV files contain all six load components, power, stall/reverse-flow diagnostics and advancing-tip-Mach margin.

## Task 7 — 3×3 trim matrix

The required matrix uses γ = 90°, 45°, 0° and V = 20, 30, 40 m/s at h=500 m, 3000 kg, ISA, level flight. The final run produced both numerically converged states and rejected states; a rejected case is intentionally documented because M2 Section 6.3 requires failure classification. See `outputs/task7_trim_status_matrix.csv` and `outputs/task7_failed_trim_case.md`.

## Task 8 — conversion corridor

The corridor map contains 19 nacelle angles (0–90° in 5° increments) × 18 airspeeds (10–44 m/s in 2 m/s increments), for 342 evaluated candidate-control states at h=500 m, 3000 kg, ISA. The map is seeded from the Task-7 trim table and is explicitly labeled as a candidate-control feasibility map rather than 342 independent nonlinear trim solves.

## Task 9 — outbound/inbound conversion

The supplied examples complete both required directions with the same aircraft configuration:

- Outbound: takeoff/initial climb → hover-to-airplane conversion → airplane-mode hold.
- Inbound: airplane-mode hold → airplane-to-hover conversion → hover descent.

The final runs pass all hard mission constraints. Detailed time histories and summaries are in `outputs/task9_*` and `figures/task9_*`.

## Task 10 — M1 feedback carried into M2

The final range sanity check uses speed-dependent required-lift drag in steady level airplane-mode flight. At 500 m and 3000 kg with 450 kg usable fuel after reserve, the calculated range peaks at about 48 m/s and falls toward 140 m/s. This directly addresses the M1 grading observation that the high-speed end should not remain monotonic.
