"""Assemble the precomputed Task 11 per-rate mission results and reproduce the cross-rate figure.

This is a fast, deterministic summary/plot step. To recompute the coupled missions from
scratch, run `python task11_dynamic_inflow_assessment.py C` (which takes longer).
"""
from __future__ import annotations
import csv
import json
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data" / "dynamic_inflow_conversion_summaries"
OUT = ROOT / "outputs"
FIG = ROOT / "figures"
for d in (OUT, FIG):
    d.mkdir(parents=True, exist_ok=True)
with (ROOT / "inputs" / "dynamic_inflow_assessment.json").open(encoding="utf-8") as f:
    assessment_cfg = json.load(f)
with (ROOT / "inputs" / "aircraft_config.json").open(encoding="utf-8") as f:
    aircraft_cfg = json.load(f)
ALTITUDE_M = float(assessment_cfg["rotor_condition"]["altitude_m"])
START_MASS_KG = float(aircraft_cfg["aircraft"]["gross_weight_kg"])
INITIAL_FUEL_KG = float(aircraft_cfg["aircraft"]["fuel_capacity_kg"])

rows = []
for suffix in (1, 2, 4, 8):
    # Prefer the latest recomputed per-rate output; fall back to the supplied
    # reproducibility snapshot if a rate has not been rerun.
    latest = OUT / f"task11_C_summary_s{suffix}.csv"
    path = latest if latest.exists() else DATA / f"summary_s{suffix}.csv"
    with path.open(newline="", encoding="utf-8") as f:
        loaded = list(csv.DictReader(f))
    if len(loaded) != 1:
        raise ValueError(f"Expected exactly one computed result row in {path}")
    row = loaded[0]
    bool_fields = {"success_baseline", "success_QS", "success_dynamic"}
    for k in bool_fields:
        row[k] = row[k].strip().lower() == "true"
    for k, v in list(row.items()):
        if k not in bool_fields:
            row[k] = float(v)
    rows.append(row)
rows.sort(key=lambda r: r["nacelle_rate_deg_s"])
fields = list(rows[0].keys())
with (OUT / "task11_C_conversion_summary.csv").open("w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader(); w.writerows(rows)

rates = np.array([r["nacelle_rate_deg_s"] for r in rows])
fig, ax = plt.subplots(2, 2, figsize=(10.5, 7.2))
for field, label in (("Pmax_baseline_kW", "Static baseline"), ("Pmax_QS_kW", "Quasi-steady Pitt–Peters"),
                     ("Pmax_dynamic_kW", "Dynamic Pitt–Peters")):
    ax[0, 0].plot(rates, [r[field] for r in rows], "o-", label=label)
ax[0, 0].set_xlabel("Nacelle rotation rate [deg/s]")
ax[0, 0].set_ylabel("Peak aircraft power required [kW]")
ax[0, 0].set_title("Peak power across conversion-rate cases")
ax[0, 0].legend(fontsize=8); ax[0, 0].grid(alpha=0.3)
ax[0, 1].plot(rates, [r["max_abs_dyn_minus_QS_kW"] for r in rows], "o-")
ax[0, 1].set_xlabel("Nacelle rotation rate [deg/s]")
ax[0, 1].set_ylabel("Maximum |dynamic − QS power| [kW]")
ax[0, 1].set_title("Effect attributable to inflow dynamics")
ax[0, 1].grid(alpha=0.3)
for field, label in (("fuel_baseline_kg", "Static baseline"), ("fuel_QS_kg", "Quasi-steady Pitt–Peters"),
                     ("fuel_dynamic_kg", "Dynamic Pitt–Peters")):
    ax[1, 0].plot(rates, [INITIAL_FUEL_KG - r[field] for r in rows], "o-", label=label)
ax[1, 0].set_xlabel("Nacelle rotation rate [deg/s]")
ax[1, 0].set_ylabel("Fuel burned over mission [kg]")
ax[1, 0].set_title("Fuel-burn comparison")
ax[1, 0].legend(fontsize=8); ax[1, 0].grid(alpha=0.3)
ax[1, 1].plot(rates, [r["min_stall_margin_QS"] for r in rows], "o-", label="Quasi-steady Pitt–Peters")
ax[1, 1].plot(rates, [r["min_stall_margin_dynamic"] for r in rows], "o-", label="Dynamic Pitt–Peters")
ax[1, 1].set_xlabel("Nacelle rotation rate [deg/s]")
ax[1, 1].set_ylabel("Minimum rotor stall margin [percentage points]")
ax[1, 1].set_title("Minimum reported stall margin")
ax[1, 1].legend(fontsize=8); ax[1, 1].grid(alpha=0.3)
fig.suptitle(f"Task 11 conversion sensitivity — {START_MASS_KG:.0f} kg nominal start mass, h={ALTITUDE_M:.0f} m\n"
             "Time-compressed schedules are sensitivity cases, not recommended operating procedures", fontsize=10)
fig.tight_layout()
fig.savefig(FIG / "task11_C_conversion_rate_summary.png", dpi=200)
plt.close(fig)

lines = [
    "# Task 11 conversion-rate assessment summary", "",
    "This table combines the per-rate results computed by `MissionPlannerV2` for the three inflow modes.",
    "The run configuration is a sensitivity study using compressed mission schedules; these are not operational recommendations.",
    "The full rerun command is `python task11_dynamic_inflow_assessment.py C`. The summary plot is reproduced by `python task11_conversion_summary.py`.", "",
    "| Nacelle rate (deg/s) | All modes succeeded? | Peak power baseline (kW) | Peak power QS (kW) | Peak power dynamic (kW) | max |ΔP| dynamic−QS (kW) | dynamic fuel burned (kg) | min stall margin dynamic (pp) |",
    "|---:|:---:|---:|---:|---:|---:|---:|---:|"
]
for r in rows:
    all_ok = all(r[k] for k in ("success_baseline", "success_QS", "success_dynamic"))
    lines.append(f"| {r['nacelle_rate_deg_s']:.2f} | {'Yes' if all_ok else 'No'} | {r['Pmax_baseline_kW']:.2f} | {r['Pmax_QS_kW']:.2f} | {r['Pmax_dynamic_kW']:.2f} | {r['max_abs_dyn_minus_QS_kW']:.2f} | {INITIAL_FUEL_KG-r['fuel_dynamic_kg']:.3f} | {r['min_stall_margin_dynamic']:.1f} |")
lines += ["", "## Interpretation", "", 
          "Across these computed cases the dynamic and quasi-steady Pitt–Peters predictions are close but not identical. The largest reported power difference is only a few kW (roughly 1.4–1.6% of the QS power at the time of maximum difference), while the static M2 baseline differs from both Pitt–Peters modes because it uses a different inflow model. The very similar minimum stall margins in this set are driven by the low-order M2 margin/flagging logic; they should not be interpreted as high-fidelity rotor-stall certification.",
          "", "## Provenance and limitation", "", 
          "The inputs are the saved single-row summaries in `data/dynamic_inflow_conversion_summaries/`. Those rows were produced by separate `MissionPlannerV2` runs for each rate and inflow model. The combined figure is a plot of those computed summaries. Analytical hover verification does not replace direct validation against measured forward-flight/transient inflow data.", ""]
(OUT / "task11_C_conversion_summary.md").write_text("\n".join(lines), encoding="utf-8")

# Re-create the time-history comparison from persisted mission runs as well. This
# avoids recomputing the coupled missions merely to regenerate their plots.
def read_history(path):
    with path.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    for row in rows:
        for k, v in list(row.items()):
            if k in {"segment", "active_constraint", "inflow_model"}:
                continue
            try:
                row[k] = float(v)
            except (ValueError, TypeError):
                pass
    return rows

fig, ax = plt.subplots(2, 2, figsize=(11, 7))
factors = [int(r["time_compression"]) for r in rows]
model_files = {"baseline": "baseline", "QS-PP": "QS_PP", "dynamic-PP": "dynamic_PP"}
# Top row compares all three inflow models at the slowest and fastest rate.
for j, factor in enumerate((factors[0], factors[-1])):
    histories = {model: read_history(OUT / f"task11_C_history_{filekey}_s{factor}.csv")
                 for model, filekey in model_files.items()}
    for model, hist in histories.items():
        ax[0, j].plot([r["time_s"] for r in hist], [r["P_required_kW"] for r in hist],
                      lw=1.4, label=model)
    rate = float(next(r["nacelle_rate_deg_s"] for r in rows if int(r["time_compression"]) == factor))
    ax[0, j].set_title(f"Power required, nacelle rate {rate:.1f} deg/s")
    ax[0, j].set_xlabel("Mission time [s]"); ax[0, j].set_ylabel("Aircraft power required [kW]")
    ax[0, j].grid(alpha=0.3); ax[0, j].legend(fontsize=8)
# Bottom left: dynamic minus quasi-steady power on the normalized original timeline.
for factor in factors:
    dyn = read_history(OUT / f"task11_C_history_dynamic_PP_s{factor}.csv")
    qs = read_history(OUT / f"task11_C_history_QS_PP_s{factor}.csv")
    n = min(len(dyn), len(qs))
    t = np.array([r["time_s"] for r in dyn[:n]]) * factor
    delta = np.array([dyn[i]["P_required_kW"] - qs[i]["P_required_kW"] for i in range(n)])
    rate = float(next(r["nacelle_rate_deg_s"] for r in rows if int(r["time_compression"]) == factor))
    ax[1, 0].plot(t, delta, label=f"{rate:.1f} deg/s")
ax[1, 0].set_xlabel("Time × compression factor [s]"); ax[1, 0].set_ylabel("Dynamic − QS power [kW]")
ax[1, 0].legend(fontsize=8); ax[1, 0].grid(alpha=0.3)
# Bottom right: compact scalar view.
ax[1, 1].plot([r["nacelle_rate_deg_s"] for r in rows], [r["max_abs_dyn_minus_QS_kW"] for r in rows], "o-")
ax[1, 1].set_xlabel("Nacelle rate [deg/s]"); ax[1, 1].set_ylabel("Maximum |dynamic − QS power| [kW]")
ax[1, 1].grid(alpha=0.3)
fig.suptitle(f"Outbound hover-to-airplane conversion — {START_MASS_KG:.0f} kg nominal start mass, h={ALTITUDE_M:.0f} m\n"
             "Time-compressed cases are sensitivity studies, not operational recommendations", fontsize=10)
fig.tight_layout(); fig.savefig(FIG / "task11_C_conversion.png", dpi=200); plt.close(fig)

print(f"Wrote outputs/task11_C_conversion_summary.csv and .md")
print(f"Wrote figures/task11_C_conversion_rate_summary.png from {len(rows)} saved per-rate results")
