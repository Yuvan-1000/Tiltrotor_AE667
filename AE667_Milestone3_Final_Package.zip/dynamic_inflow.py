"""
dynamic_inflow.py
================================================================================
Pitt-Peters 3-state dynamic inflow model for the Tiltrotor_AE667 prediction tool.

Model
-----
The induced-inflow ratio over the disk is represented by its first harmonics

    lambda_i(r, psi) = lam0 + lam_s * (r/R) * sin(psi_pp) + lam_c * (r/R) * cos(psi_pp)

and the three states x = [lam0, lam_s, lam_c] obey (non-dimensional time psi = Omega*t)

    M dx/dpsi + L(x)^-1 x = tau ,        tau = [C_T, C_L, C_M]

    M = diag(M0, M1, M1)       apparent-mass terms
    L = L(mu, lam_total, lam0) wake-skew-dependent influence matrix

so dx/dt = Omega * M^-1 (tau - L^-1 x).  Setting dx/dt = 0 gives the STATIC
(quasi-steady) inflow, x = L tau, which is the baseline mode: for pure thrust
it reduces to momentum / Glauert theory (lam0 = C_T / (2 V_T)).

Conventions (checked against edgewise_bemt.py of the M2 package)
----------------------------------------------------------------
- Rotor frame: z_R = thrust direction, x_R points AFT at gamma = 90 deg,
  y_R = z_R x x_R (starboard).  psi = 0 along +x_R (aft), psi = 90 deg along
  +y_R, advancing side for rotation_sign = +1.  This is also the Pitt-Peters
  azimuth convention (psi = 0 downwind/aft).
- C_T = T / (rho A (Omega R)^2)
- C_L = rolling-moment coefficient, positive RIGHT-SIDE-DOWN  (about forward axis)
- C_M = pitching-moment coefficient, positive NOSE-UP         (about starboard axis)
  both normalised by rho A (Omega R)^2 R.
  From the rotor-frame hub moments of EdgewiseBEMTSolver.solve():
      C_L = -rotation_sign * M_hub_rotor[0] / (q R),   C_M = +M_hub_rotor[1] / (q R)
- mu = V_edge/(Omega R), lam_c = V_axial/(Omega R)  (through-disk flow positive
  in the direction that adds to the induced flow, same as EdgewiseFlightCondition.V_axial)
- lam_total = lam_c + lam0   (total inflow normal to the disk)

Source-backed parameter convention and implementation mapping
---------------------------------------------------------------
The default apparent-mass constants are the canonical three-state Pitt-Peters
values M0 = 128/(75 pi) and M1 = 64/(45 pi), as documented in the BladeAD Pitt-Peters
model background (which cites Pitt & Peters, 1980/1981). The implementation uses
a sign/permutation-transformed state/load convention compatible with the M2 rotor
axes; therefore the two cyclic entries appear with negative signs in mass_diag().
The nonlinear mass-flow terms use V_T and V_m defined below. The exact axis and
moment mappings are documented in forcing_from_edgewise_result() and the module
conventions. Tests verify the implementation against analytical/model limits; they
are code-verification tests, not a replacement for an experimental validation.

Limitations
-----------
Valid for positive total inflow (hover, climb, edgewise/forward flight, tiltrotor
conversion).  Vortex-ring / windmill-brake states (lam_total <= 0) are outside the
model; inflow terms are floored at `v_floor` and a flag is raised.
Only numpy is required.
================================================================================
"""
from __future__ import annotations

import math
import warnings
from dataclasses import dataclass, field
from typing import Dict, Optional, Tuple

import numpy as np

# ----------------------------------------------------------------------------
# Parameters
# ----------------------------------------------------------------------------

# Canonical three-state constants. The cyclic coordinates in this implementation
# have a sign-transformed basis (see mass_diag and module conventions), but not a
# rescaled amplitude; therefore M1 = 64/(45*pi), not 16/(45*pi).
_CANONICAL_M0 = 128.0 / (75.0 * math.pi)
_CANONICAL_M1 = 64.0 / (45.0 * math.pi)
_PRESETS = {
    "pitt_peters": (_CANONICAL_M0, _CANONICAL_M1),
    # Explicit alias for traceability to the original published formulation.
    "pitt_peters_1981": (_CANONICAL_M0, _CANONICAL_M1),
}


@dataclass(frozen=True)
class DynamicInflowParams:
    """Model constants. M0 -> uniform state, M1 -> both cyclic states.

    v_floor : lower bound on V_T, V_m and total inflow [-] (keeps L finite at
              zero thrust / zero speed; also marks the model-validity edge)."""

    M0: float = _PRESETS["pitt_peters"][0]
    M1: float = _PRESETS["pitt_peters"][1]
    v_floor: float = 1e-3

    @classmethod
    def preset(cls, name: str = "pitt_peters", **kw) -> "DynamicInflowParams":
        if name not in _PRESETS:
            raise ValueError(f"unknown preset {name!r}; choose from {sorted(_PRESETS)}")
        M0, M1 = _PRESETS[name]
        return cls(M0=M0, M1=M1, **kw)

    def mass_diag(self) -> np.ndarray:
        # signs follow the (C_L, C_M) convention in the module docstring
        return np.array([self.M0, -self.M1, -self.M1])


# ----------------------------------------------------------------------------
# Model matrices
# ----------------------------------------------------------------------------

def _validate(Omega: float, mu: float) -> None:
    if not Omega > 0.0:
        raise ValueError("Omega must be > 0")
    if mu < 0.0:
        raise ValueError("mu must be >= 0 (direction is carried by the psi convention)")


def mass_flow_parameters(lam: np.ndarray, lam_c: float, mu: float,
                         p: DynamicInflowParams) -> Tuple[float, float, float, bool]:
    """Return (V_T, V_m, chi, ok). ok=False if the model validity edge was hit."""
    lam_tot = lam_c + float(lam[0])
    ok = lam_tot > p.v_floor
    lam_tot = max(lam_tot, p.v_floor)
    V_T = max(math.hypot(mu, lam_tot), p.v_floor)
    V_m = max((mu * mu + lam_tot * (lam_tot + float(lam[0]))) / V_T, p.v_floor)
    chi = math.atan2(mu, lam_tot)           # wake skew angle from the rotor axis
    return V_T, V_m, chi, ok


def L_matrix(lam: np.ndarray, lam_c: float, mu: float,
             p: DynamicInflowParams = DynamicInflowParams()) -> np.ndarray:
    V_T, V_m, chi, _ = mass_flow_parameters(lam, lam_c, mu, p)
    t = math.tan(0.5 * chi)
    c = math.cos(chi)
    k = 15.0 * math.pi / 64.0
    return np.array([
        [1.0 / (2.0 * V_T), 0.0, k * t / V_m],
        [0.0, -4.0 / (V_m * (1.0 + c)), 0.0],
        [k * t / V_T, 0.0, -4.0 * c / (V_m * (1.0 + c))],
    ])


def inflow_rates(lam: np.ndarray, tau: np.ndarray, Omega: float, lam_c: float,
                 mu: float, p: DynamicInflowParams = DynamicInflowParams()) -> np.ndarray:
    """d(lam)/dt [1/s]."""
    L = L_matrix(lam, lam_c, mu, p)
    return Omega * (np.asarray(tau, float) - np.linalg.solve(L, lam)) / p.mass_diag()


def stiffness_rate(lam: np.ndarray, Omega: float, lam_c: float, mu: float,
                   p: DynamicInflowParams = DynamicInflowParams()) -> float:
    """Largest |eigenvalue| of Omega M^-1 L^-1 [1/s] = fastest inflow rate (sets explicit dt limit)."""
    L = L_matrix(lam, lam_c, mu, p)
    A = np.linalg.inv(L) / p.mass_diag()[:, None]
    return float(Omega * np.max(np.abs(np.linalg.eigvals(A))))


# ----------------------------------------------------------------------------
# Time integration
# ----------------------------------------------------------------------------

def step(lam: np.ndarray, tau: np.ndarray, Omega: float, lam_c: float, mu: float,
         dt: float, p: DynamicInflowParams = DynamicInflowParams(),
         method: str = "rk4") -> np.ndarray:
    """One fixed step with frozen tau, lam_c, mu.  NO substepping (see advance()).

    method: 'euler' (1st order, explicit), 'rk4' (4th order, explicit),
            'implicit' (1st order, backward Euler with L frozen at the step start;
            unconditionally stable for the frozen linear system)."""
    _validate(Omega, mu)
    lam = np.asarray(lam, float)
    tau = np.asarray(tau, float)
    f = lambda x: inflow_rates(x, tau, Omega, lam_c, mu, p)
    if method == "euler":
        return lam + dt * f(lam)
    if method == "rk4":
        k1 = f(lam)
        k2 = f(lam + 0.5 * dt * k1)
        k3 = f(lam + 0.5 * dt * k2)
        k4 = f(lam + dt * k3)
        return lam + dt / 6.0 * (k1 + 2.0 * k2 + 2.0 * k3 + k4)
    if method == "implicit":
        L = L_matrix(lam, lam_c, mu, p)
        A = np.linalg.inv(L)
        Md = p.mass_diag()
        lhs = np.diag(Md / (Omega * dt)) + A
        rhs = Md * lam / (Omega * dt) + tau
        return np.linalg.solve(lhs, rhs)
    raise ValueError("method must be 'euler', 'rk4' or 'implicit'")


def advance(lam: np.ndarray, tau: np.ndarray, Omega: float, lam_c: float, mu: float,
            dt: float, p: DynamicInflowParams = DynamicInflowParams(),
            method: str = "rk4", cfl: float = 0.5,
            max_substep_s: Optional[float] = None) -> np.ndarray:
    """Advance over a (possibly large) interval dt, e.g. a mission-planner step.

    The interval is split into sub-steps so that explicit methods stay stable:
    sub-step <= cfl / (fastest inflow rate).  tau, lam_c, mu are held constant
    over dt (re-call per planner step with updated values)."""
    _validate(Omega, mu)
    if dt < 0.0:
        raise ValueError("dt must be >= 0")
    if dt == 0.0:
        return np.asarray(lam, float).copy()
    lam = np.asarray(lam, float).copy()
    rate = stiffness_rate(lam, Omega, lam_c, mu, p)
    n = 1 if method == "implicit" else max(1, math.ceil(dt * rate / cfl))
    if max_substep_s is not None:
        n = max(n, math.ceil(dt / max_substep_s))
    h = dt / n
    for _ in range(n):
        lam = step(lam, tau, Omega, lam_c, mu, h, p, method)
    return lam


def steady_state(tau: np.ndarray, lam_c: float, mu: float,
                 p: DynamicInflowParams = DynamicInflowParams(),
                 tol: float = 1e-12, max_iter: int = 500) -> np.ndarray:
    """Static (quasi-steady) inflow, x = L(x) tau  -- the BASELINE mode."""
    tau = np.asarray(tau, float)
    lam = np.array([max(math.sqrt(max(tau[0], 1e-8) / 2.0), p.v_floor), 0.0, 0.0])
    for _ in range(max_iter):
        new = L_matrix(lam, lam_c, mu, p) @ tau
        nxt = 0.5 * lam + 0.5 * new            # damped (Heron-type) fixed point
        if np.max(np.abs(nxt - lam)) < tol:
            return nxt
        lam = nxt
    raise RuntimeError("steady_state did not converge (check tau, lam_c, mu)")


# ----------------------------------------------------------------------------
# Interface to the existing prediction tool
# ----------------------------------------------------------------------------

def forcing_from_edgewise_result(res: Dict, R: float, rotation_sign: float = 1.0) -> np.ndarray:
    """tau = [C_T, C_L, C_M] from an EdgewiseBEMTSolver.solve() result dict.

    Uses res['T'], res['M_hub_rotor'] (rotor frame, N m), res['rho'], res['Vtip']."""
    q = res["rho"] * math.pi * R ** 2 * res["Vtip"] ** 2
    Mx, My = float(res["M_hub_rotor"][0]), float(res["M_hub_rotor"][1])
    return np.array([res["T"] / q,
                     -rotation_sign * Mx / (q * R),
                     My / (q * R)])


def inflow_at(lam: np.ndarray, r_over_R, psi, rotation_sign: float = 1.0) -> np.ndarray:
    """lambda_i(r, psi) in the repo's (r, psi) grid convention.

    Repo psi runs with the geometric angle from +x_R; for rotation_sign = -1 the
    Pitt-Peters azimuth is psi_pp = -psi, so only the sin term changes sign."""
    r = np.asarray(r_over_R, float)
    ps = np.asarray(psi, float)
    return lam[0] + rotation_sign * lam[1] * r * np.sin(ps) + lam[2] * r * np.cos(ps)


def drees_first_harmonic_ratio(mu: float, lam_G: float) -> float:
    """Repo baseline: kappa = 1 + k (r/R) cos(psi), k = (4/3) x/(1.2+x), x = mu/lam_G.
    Equals lam_c/lam0 of the static model -> compare with static Pitt-Peters."""
    x = mu / max(lam_G, 1e-9)
    return (4.0 / 3.0) * x / (1.2 + x)


def pitt_peters_pure_thrust_ratio(mu: float, lam_total: float) -> float:
    """lam_c/lam0 of the STATIC Pitt-Peters model for a pure-thrust load: (15 pi/32) tan(chi/2)."""
    return 15.0 * math.pi / 32.0 * math.tan(0.5 * math.atan2(mu, lam_total))


# ----------------------------------------------------------------------------
# Convenience wrapper that carries the state (for the mission planner)
# ----------------------------------------------------------------------------

@dataclass
class PittPetersInflow:
    params: DynamicInflowParams = field(default_factory=DynamicInflowParams)
    lam: np.ndarray = field(default_factory=lambda: np.zeros(3))
    valid: bool = True

    def reset_steady(self, tau, lam_c: float, mu: float) -> None:
        self.lam = steady_state(tau, lam_c, mu, self.params)

    def advance(self, tau, Omega: float, lam_c: float, mu: float, dt: float,
                method: str = "rk4") -> np.ndarray:
        self.lam = advance(self.lam, tau, Omega, lam_c, mu, dt, self.params, method)
        _, _, _, ok = mass_flow_parameters(self.lam, lam_c, mu, self.params)
        if not ok and self.valid:
            warnings.warn("Dynamic inflow: total inflow <= 0 (vortex-ring/windmill regime) - model invalid.")
        self.valid = self.valid and ok
        return self.lam


# ----------------------------------------------------------------------------
# Demo: hover thrust step vs exact solution (writes a figure if matplotlib exists)
# ----------------------------------------------------------------------------

def hover_step_exact(t, lam_a: float, lam_f: float, Omega: float,
                     p: DynamicInflowParams = DynamicInflowParams()):
    """Exact lam0(t) for a hover thrust step (mu = 0, lam_c = 0, V_T = lam0):
        M0 dlam/dpsi = C_T - 2 lam^2   ->   lam = lam_f tanh(atanh(lam_a/lam_f) + 2 lam_f Omega t / M0)
    (lam_a < lam_f; for lam_a > lam_f replace tanh by coth)."""
    t = np.asarray(t, float)
    arg = 2.0 * lam_f * Omega * t / p.M0
    if lam_a < lam_f:
        return lam_f * np.tanh(math.atanh(lam_a / lam_f) + arg)
    return lam_f / np.tanh(math.atanh(lam_f / lam_a) + arg)


def _demo():
    import os
    Omega = 750.0 * 2.0 * math.pi / 60.0
    CT1, CT2 = 0.0030, 0.0045
    p = DynamicInflowParams()
    lam = steady_state([CT1, 0, 0], 0.0, 0.0, p)
    lam_a, lam_f = lam[0], math.sqrt(CT2 / 2.0)
    tau_lin = p.M0 / (4.0 * lam_f * Omega)
    t = np.linspace(0, 0.5, 501)
    x, num = lam.copy(), []
    for k in range(len(t)):
        num.append(x[0])
        x = step(x, [CT2, 0, 0], Omega, 0.0, 0.0, t[1] - t[0], p, "rk4")
    num = np.array(num)
    ex = hover_step_exact(t, lam_a, lam_f, Omega, p)
    print(f"hover step C_T {CT1}->{CT2} at 750 RPM: linearised time constant "
          f"tau = M0/(4 lam_f Omega) = {tau_lin * 1e3:.1f} ms; max |num-exact| = {np.max(np.abs(num - ex)):.2e}")
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        os.makedirs("figures", exist_ok=True)
        fig, ax = plt.subplots(figsize=(6, 3.8))
        ax.plot(t * 1e3, ex, "k-", lw=2, label="exact (tanh) solution")
        ax.plot(t[::25] * 1e3, num[::25], "ro", ms=4, label="RK4, dt = 1 ms")
        ax.axhline(lam_f, color="gray", ls="--", lw=0.8, label="static (quasi-steady) value")
        ax.set_xlabel("time since thrust step [ms]"); ax.set_ylabel(r"uniform inflow ratio $\lambda_0$ [-]")
        ax.set_title("Hover thrust step, 750 RPM: dynamic inflow lag"); ax.legend(); ax.grid(alpha=0.3)
        fig.tight_layout(); fig.savefig("figures/dynamic_inflow_hover_step.png", dpi=200)
        print("saved figures/dynamic_inflow_hover_step.png")
    except ImportError:
        pass


if __name__ == "__main__":
    _demo()
