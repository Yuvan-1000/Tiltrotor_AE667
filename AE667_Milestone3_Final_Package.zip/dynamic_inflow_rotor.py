"""
dynamic_inflow_rotor.py
================================================================================
Couples the Pitt-Peters model (dynamic_inflow.py) to EdgewiseBEMTSolver.

Inflow field used in dynamic mode (disk-averaged states from the ODE, spanwise
shape from the validated M1 axial BEMT):

    lambda_i(r, psi) = lam0 * shape(r) + rot * lam_s (r/R) sin(psi) + lam_c (r/R) cos(psi)

    shape(r) = lam0_BEMT(r) / lam_bar_BEMT      (area-weighted mean = 1)

so the radial distribution (tip loss, twist effects) is inherited from M1, while
the disk-mean level and the first azimuthal harmonics are dynamic states.

Three inflow models can be compared on the same rotor:
  "static"            : original M2 Glauert/Drees inflow (EdgewiseBEMTSolver.solve(flight))
  quasi-steady P-P    : equilibrium(flight)  -> dx/dt = 0, loads and inflow consistent
  "pitt_peters"       : advance(flight, state, dt) -> time-accurate dynamic inflow
================================================================================
"""
from __future__ import annotations

import math
import warnings
from typing import Dict, Optional, Tuple

import numpy as np

import dynamic_inflow as di
from edgewise_bemt import EdgewiseBEMTSolver, EdgewiseFlightCondition


class DynamicInflowRotor:
    def __init__(self, solver: EdgewiseBEMTSolver,
                 params: Optional[di.DynamicInflowParams] = None):
        self.solver = solver
        self.params = params or di.DynamicInflowParams()
        self.R = solver.geom.R

    # ------------------------------------------------------------------ geometry
    def _grids(self, flight: EdgewiseFlightCondition):
        r, dr = self.solver.geom.stations()
        psi = np.linspace(0.0, 2.0 * np.pi, int(flight.n_azimuth), endpoint=False)
        Rg, PSIg = np.meshgrid(r, psi, indexing="ij")
        _, lam0 = self.solver._baseline_inflow(flight)       # cached M1 axial solution
        w = r * dr
        lam_bar = float(np.sum(lam0 * w) / np.sum(w))
        shape = lam0 / lam_bar if lam_bar > 1e-9 else np.ones_like(lam0)
        return Rg, PSIg, shape

    def _nondim(self, flight: EdgewiseFlightCondition) -> Tuple[float, float]:
        Vtip = flight.Omega * self.R
        return flight.V_edge / Vtip, flight.V_axial / Vtip     # mu, lam_c(climb ratio)

    def inflow_field(self, flight: EdgewiseFlightCondition, lam_state: np.ndarray) -> np.ndarray:
        Rg, PSIg, shape = self._grids(flight)
        harmonics = di.inflow_at(np.array([0.0, lam_state[1], lam_state[2]]),
                                 Rg / self.R, PSIg, flight.rotation_sign)
        return lam_state[0] * shape[:, None] + harmonics

    # ------------------------------------------------------------------ loads
    def forcing(self, res: Dict, flight: EdgewiseFlightCondition) -> np.ndarray:
        return di.forcing_from_edgewise_result(res, self.R, flight.rotation_sign)

    def loads(self, flight: EdgewiseFlightCondition, lam_state: np.ndarray) -> Dict:
        """Rotor loads for the given inflow state (no iteration). Adds 'inflow_state', 'tau'."""
        res = self.solver.solve(flight, inflow_override=self.inflow_field(flight, lam_state))
        res["inflow_state"] = np.asarray(lam_state, float).copy()
        res["tau"] = self.forcing(res, flight)
        return res

    # ------------------------------------------------------------------ equilibrium (quasi-steady P-P)
    def equilibrium(self, flight: EdgewiseFlightCondition, tol: float = 1e-9,
                    max_iter: int = 200, relax: float = 0.6) -> Tuple[np.ndarray, Dict]:
        """State with dx/dt = 0 and loads consistent with it (fixed-point iteration)."""
        mu, lam_c = self._nondim(flight)
        res0 = self.solver.solve(flight)                          # static solution as start
        lam = di.steady_state(self.forcing(res0, flight), lam_c, mu, self.params)
        for _ in range(max_iter):
            res = self.loads(flight, lam)
            new = di.steady_state(res["tau"], lam_c, mu, self.params)
            if np.max(np.abs(new - lam)) < tol:
                return new, self.loads(flight, new)
            lam = lam + relax * (new - lam)
        warnings.warn("Dynamic-inflow equilibrium did not converge")
        return lam, self.loads(flight, lam)

    # ------------------------------------------------------------------ time marching
    def _rates(self, lam, flight, mu, lam_c):
        res = self.loads(flight, lam)
        return di.inflow_rates(lam, res["tau"], flight.Omega, lam_c, mu, self.params)

    def advance(self, flight: EdgewiseFlightCondition, lam_state: np.ndarray, dt: float,
                method: str = "rk4", cfl: float = 0.5, settle_factor: float = 10.0
                ) -> np.ndarray:
        """Advance the inflow state by dt under constant controls/flight condition.

        Loads are re-evaluated at every sub-step (thrust depends on the inflow state).
        If dt exceeds `settle_factor` slowest time constants the state has relaxed to
        equilibrium and the equilibrium solution is returned directly (exact to
        exp(-settle_factor) and much cheaper)."""
        if dt < 0:
            raise ValueError("dt must be >= 0")
        lam = np.asarray(lam_state, float).copy()
        if dt == 0.0:
            return lam
        mu, lam_c = self._nondim(flight)
        p = self.params
        rate_fast = di.stiffness_rate(lam, flight.Omega, lam_c, mu, p)
        L = di.L_matrix(lam, lam_c, mu, p)
        A = np.linalg.inv(L) / p.mass_diag()[:, None]
        rate_slow = float(flight.Omega * np.min(np.abs(np.linalg.eigvals(A))))
        if dt * rate_slow > settle_factor:
            return self.equilibrium(flight)[0]
        n = max(1, math.ceil(dt * rate_fast / cfl))
        h = dt / n
        f = lambda x: self._rates(x, flight, mu, lam_c)
        for _ in range(n):
            if method == "euler":
                lam = lam + h * f(lam)
            elif method == "rk4":
                k1 = f(lam); k2 = f(lam + 0.5 * h * k1)
                k3 = f(lam + 0.5 * h * k2); k4 = f(lam + h * k3)
                lam = lam + h / 6.0 * (k1 + 2 * k2 + 2 * k3 + k4)
            else:
                raise ValueError("method must be 'euler' or 'rk4'")
        return lam
