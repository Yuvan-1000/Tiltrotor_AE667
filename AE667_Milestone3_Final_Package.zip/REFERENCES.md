# References

1. Knight, M., & Hefner, R. A. (1937). *Static Thrust Analysis of the Lifting Airscrew*. NACA Technical Note 626. Validation data reproduced from the Milestone-1 package / course handout.
2. Leishman, J. G. *Principles of Helicopter Aerodynamics*. Cambridge University Press. BEMT, rotor aerodynamics and forward-flight background.
3. AE 667, IIT Bombay, course handout: *Milestone 2 — Edgewise Flight, Cyclic Control, and Trimmed Conversion*. Primary project requirements and non-uniform inflow relation.
4. AE 667 lecture: *Blade Element Theory*. Strip/blade-element force and torque formulation.
5. AE 667 lecture: *Blade Element Momentum Theory*. Momentum/blade-element coupling and induced-flow treatment.
6. AE 667 lecture: *Rotors in Forward Flight (Blade Dynamics)*. Forward-flight coordinate conventions, advancing/retreating sides and cyclic-pitch convention.
7. AE 667 lecture: *Forward Flight — Performance Prediction*. Forward-flight force balance and Glauert conceptual inflow model.
8. AE 667 lecture: *Vehicle Performance*. Airframe drag, engine power and performance-parameter background.
9. AE 667 lecture: *Coning Angle*. Rotor hub/flapping background.
10. AE 667 lecture: *Momentum Theory*. Rotor momentum relationships.
11. AE 667 lecture: *Vortex Theory*. Wake contraction and limitations relevant to simplified rotor models.
12. Python packages used: NumPy and Matplotlib.

## Dynamic inflow references added for this extension

13. Pitt, D. M., & Peters, D. A. (1981). “Theoretical Prediction of Dynamic-Inflow Derivatives.” *Vertica*, 5(1), 21–34. Foundational three-state dynamic-inflow formulation. Bibliographic record: https://mst.elsevierpure.com/en/publications/theoretical-prediction-of-dynamic-inflow-derivatives/
14. Chen, R. T. N., & Hindson, W. S. (1986). *Influence of Dynamic Inflow on the Helicopter Vertical Response*. NASA Technical Memorandum 88327. Comparative dynamic-response study including measured helicopter response. https://ntrs.nasa.gov/citations/19870047579
15. Chen, R. T. N. (1989). *A Survey of Nonuniform Inflow Models for Rotorcraft Flight Dynamics and Control Applications*. NASA Technical Memorandum 102219. Review of inflow models and available comparisons. https://ntrs.nasa.gov/citations/19900051466
16. Hoad, D. R. (1990). *Rotor Induced-Inflow-Ratio Measurements and CAMRAD Calculations*. NASA Technical Paper 2946. Measured inflow distributions and comparison calculations. https://ntrs.nasa.gov/citations/19900006566
17. BladeAD documentation. “Pitt-Peters Inflow Model.” Formula and canonical apparent-mass coefficients used as a cross-check for the implementation. https://bladead.readthedocs.io/en/latest/src/background/pitt_peters.html
18. BladeAD documentation. “NASA Reports — Inflow Model Validation.” Secondary documentation showing benchmark inflow distributions for NASA rotor cases; consult the underlying NASA references before conducting a direct quantitative comparison. https://bladead.readthedocs.io/en/latest/src/vnv/nasa_reports.html

## Milestone 3 published-aircraft comparison

19. The Boeing Company. *V-22 Osprey — Specifications*. Manufacturer specification page. Used for rotor diameter and Rolls-Royce AE1107C engine rating. https://www.boeing.com/defense/military-rotorcraft/v-22-osprey (accessed 6 November 2026).
20. Bell Textron Inc. *Bell Boeing V-22 — Specifications*. Manufacturer product page. Used for published maximum cruise speed, vertical-takeoff maximum gross weight, and single cargo-hook load. https://www.bellflight.com/products/bell-boeing-v-22 (accessed 6 November 2026).
21. Bell Textron Inc. *Bell Boeing V-22 Osprey Data Brochure*. Used as cross-check for rotor diameter, vertical takeoff gross weight, cargo-hook capacity and engine rating. https://www.bellflight.com/-/media/site-specific/bell-flight/documents/products/v-22/bell-boeing-v-22-data-brochure.pdf (accessed 6 November 2026).
