"""Integration tests: dynamic inflow inside EdgewiseBEMTSolver / aircraft model / MissionPlannerV2.

I1  baseline recovery  : static mode reproduces the ORIGINAL M2 solver and mission planner
                         (golden numbers generated from the unmodified code)
I2  hook consistency   : feeding the static inflow field back through inflow_override is identical
I3  equilibrium        : quasi-steady Pitt-Peters state is a true fixed point; hover ~ static
I4  physics            : collective step -> thrust overshoot then relaxation to the new equilibrium
I5  numerics           : large-dt shortcut and sub-step convergence of the coupled system
I6  mission            : static records unchanged; dynamic records carry inflow states
"""
from __future__ import annotations
import copy, json, math, os, sys, warnings
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
warnings.simplefilter("ignore")

from aircraft_config import TILTROTOR_GEOM, TILTROTOR_AIRFOIL
from edgewise_bemt import EdgewiseBEMTSolver, EdgewiseFlightCondition as F
from dynamic_inflow_rotor import DynamicInflowRotor
from mission_planner_v2 import MissionPlannerV2
import dynamic_inflow as di

GOLDEN = json.load(open(os.path.join(ROOT, "data", "dynamic_inflow_baseline_golden.json")))
SOLVER = EdgewiseBEMTSolver(TILTROTOR_GEOM, TILTROTOR_AIRFOIL)
DYN = DynamicInflowRotor(SOLVER)
KEYS = ["T", "Q", "P", "CT", "CQ", "CP", "FX", "FY", "FZ", "MX", "MY", "MZ", "lam_G", "k",
        "glauert_ratio", "stalled_span_fraction", "stall_fraction", "M_adv_tip", "reverse_flow_fraction"]


def _flight(c):
    return F.from_rpm(c["rpm"], c["col"], c.get("th1c", 0.0), c.get("th1s", 0.0), **c["kw"])


def _f(col=12.0, Ve=20.0, na=36):
    return F.from_rpm(750, col, V_edge=Ve, V_axial=0.0, n_azimuth=na, altitude=500.0)


# ------------------------------------------------------------------ I1
def test_static_solver_matches_original_code():
    for g in GOLDEN["solver"]:
        r = SOLVER.solve(_flight(g["case"]))
        for k in KEYS:
            assert math.isclose(float(r[k]), g[k], rel_tol=1e-12, abs_tol=1e-12), (g["case"], k)


def test_static_mission_matches_original_code():
    gm = GOLDEN["mission"]
    mp = MissionPlannerV2(radial_stations=gm["radial_stations"], n_azimuth=gm["n_azimuth"])  # default = static
    res = mp.run(copy.deepcopy(gm["definition"]))
    assert res["success"] == gm["success"] and len(res["history"]) == len(gm["history"])
    for h, g in zip(res["history"], gm["history"]):
        assert set(h) == set(g)                                   # CSV schema unchanged
        for k, v in g.items():
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                assert math.isclose(float(h[k]), v, rel_tol=1e-10, abs_tol=1e-9), k
            else:
                assert h[k] == v, k
    assert math.isclose(res["final_fuel_kg"], gm["final_fuel_kg"], rel_tol=1e-12)


# ------------------------------------------------------------------ I2
def test_inflow_override_with_static_field_is_identity():
    st = SOLVER.solve(_f())
    ov = SOLVER.solve(_f(), inflow_override=st["lam_i"])
    for k in ("T", "Q", "P", "FX", "FY", "FZ", "MX", "MY", "MZ"):
        assert math.isclose(ov[k], st[k], rel_tol=1e-12, abs_tol=1e-9), k


def test_inflow_override_shape_is_checked():
    try:
        SOLVER.solve(_f(), inflow_override=np.zeros((3, 3)))
    except ValueError:
        return
    raise AssertionError("expected ValueError for a wrong-shaped override")


# ------------------------------------------------------------------ I3
def test_equilibrium_is_a_fixed_point():
    f = _f()
    lam, res = DYN.equilibrium(f)
    mu = f.V_edge / (f.Omega * DYN.R)
    again = di.steady_state(res["tau"], 0.0, mu, DYN.params)
    assert np.max(np.abs(again - lam)) < 1e-7
    assert lam[2] > 0.0 and lam[1] > 0.0 > -1.0                   # more inflow aft; advancing-side loading -> lam_s>0


def test_hover_equilibrium_close_to_static_and_axisymmetric():
    f = _f(Ve=0.0, na=24)
    st = SOLVER.solve(f)
    lam, res = DYN.equilibrium(f)
    assert abs(lam[1]) < 1e-9 and abs(lam[2]) < 1e-9
    assert abs(res["T"] - st["T"]) / st["T"] < 0.10               # momentum vs BEMT-consistent hover inflow


# ------------------------------------------------------------------ I4
def test_collective_step_overshoots_then_relaxes():
    f1, f2 = _f(12.0), _f(15.0)
    lam1, r1 = DYN.equilibrium(f1)
    lam2, r2 = DYN.equilibrium(f2)
    T_jump = DYN.loads(f2, lam1)["T"]                             # inflow has not responded yet
    assert T_jump > r2["T"] > r1["T"]
    Ts = []
    lam = lam1
    for _ in range(6):
        lam = DYN.advance(f2, lam, 0.02)
        Ts.append(DYN.loads(f2, lam)["T"])
    # The coupled three-state system can show a small damped oscillation; do not
    # impose artificial monotonicity. Check initial overshoot and recovery instead.
    assert Ts[0] < T_jump
    assert abs(Ts[-1] - r2["T"]) / r2["T"] < 0.01
    lam_late = DYN.advance(f2, lam1, 2.0)
    assert np.max(np.abs(lam_late - lam2)) < 1e-6


# ------------------------------------------------------------------ I5
def test_substep_convergence_of_coupled_advance():
    f1, f2 = _f(12.0, na=24), _f(15.0, na=24)
    lam1, _ = DYN.equilibrium(f1)
    ref = DYN.advance(f2, lam1, 0.05, cfl=0.0625)
    errs = [np.max(np.abs(DYN.advance(f2, lam1, 0.05, cfl=c) - ref)) for c in (0.5, 0.25, 0.125)]
    assert errs[0] > errs[1] > errs[2] or errs[2] < 1e-10
    # RK4 step sizes are coupled to a nonlinear aerodynamic load evaluation.
    # Verify the error is small and falls with refinement rather than enforcing
    # a threshold tuned to the former (different apparent-mass) constants.
    assert errs[0] < 2.5e-4


def test_euler_and_rk4_agree_for_small_substeps():
    f1, f2 = _f(12.0, na=24), _f(15.0, na=24)
    lam1, _ = DYN.equilibrium(f1)
    a = DYN.advance(f2, lam1, 0.03, method="rk4", cfl=0.05)
    b = DYN.advance(f2, lam1, 0.03, method="euler", cfl=0.005)
    assert np.max(np.abs(a - b)) < 5e-5


# ------------------------------------------------------------------ I6
def _step_mission(dt, dur=0.3):
    c = {"pitch_deg": 0.0, "theta_1c_lateral_deg": 0.0, "theta_1s_longitudinal_deg": 0.0,
         "elevator_deg": 0.0, "rudder_deg": 0.0, "aileron_deg": 0.0}
    seg = lambda n, col: {"name": n, "duration_s": dur, "airspeed_ms": 2.0, "altitude_m": 0.0,
                          "nacelle_angle_deg": 90, "rpm": 750, "control_source": "scheduled",
                          "controls": dict(c, collective_deg=col)}
    return {"dt_s": dt, "segments": [seg("hold", 12.0), seg("step", 14.0)]}


def test_mission_dynamic_mode_records_inflow_and_shows_lag():
    mp_s = MissionPlannerV2(radial_stations=12, n_azimuth=12)
    mp_d = MissionPlannerV2(radial_stations=12, n_azimuth=12, inflow_model="pitt_peters")
    hs = mp_s.run(_step_mission(0.02))["history"]
    rd = mp_d.run(_step_mission(0.02))
    hd = rd["history"]
    assert rd["success"] and len(hs) == len(hd)
    assert "lam0_R1" in hd[0] and "lam0_R1" not in hs[0]
    seg2 = [h for h in hd if h["segment"] == "step"]
    T = [h["thrust_R1_N"] for h in seg2]
    assert T[0] > T[-1]                                           # overshoot right after the step
    assert seg2[0]["lam0_R1"] < seg2[-1]["lam0_R1"]               # inflow still catching up
    t_static_step = [h for h in hs if h["segment"] == "step"][0]["FZ_N"]
    assert seg2[0]["FZ_N"] != t_static_step                       # models genuinely differ


def test_mission_large_dt_relaxes_to_equilibrium():
    """dt >> tau: dynamic inflow collapses to the quasi-steady state at every node."""
    mp = MissionPlannerV2(radial_stations=12, n_azimuth=12, inflow_model="pitt_peters")
    h = mp.run(_step_mission(1.0, dur=2.0))["history"]
    seg2 = [r for r in h if r["segment"] == "step"]
    assert abs(seg2[1]["thrust_R1_N"] - seg2[-1]["thrust_R1_N"]) / seg2[-1]["thrust_R1_N"] < 2e-3


if __name__ == "__main__":
    fails = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn(); print("PASS", name)
            except Exception as e:                                  # noqa: BLE001
                fails += 1; print("FAIL", name, repr(e))
    sys.exit(1 if fails else 0)
