"""Verification tests for dynamic_inflow.py (run: pytest tests/test_dynamic_inflow.py -q
or python tests/test_dynamic_inflow.py).

V1  steady-state recovery  : static limit = momentum / Glauert theory
V2  hand calculation       : exact hover thrust-step solution and linearised time constant
V3  dt convergence         : observed order of Euler / implicit (1) and RK4 (4)
V4  robustness             : large mission-planner dt, eigenvalue stability, sign conventions
"""
from __future__ import annotations
import math, os, sys
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import dynamic_inflow as di

OMEGA = 750.0 * 2.0 * math.pi / 60.0       # rad/s, M1/M2 hover RPM
P = di.DynamicInflowParams()


def test_canonical_pitt_peters_apparent_mass_constants():
    """Published canonical constants for the three-state Pitt-Peters formulation."""
    assert math.isclose(P.M0, 128.0 / (75.0 * math.pi), rel_tol=0.0, abs_tol=1e-14)
    assert math.isclose(P.M1, 64.0 / (45.0 * math.pi), rel_tol=0.0, abs_tol=1e-14)
    assert np.allclose(P.mass_diag(), [P.M0, -P.M1, -P.M1])


# ------------------------------------------------------------------ V1
def test_hover_steady_equals_momentum():
    for CT in (0.001, 0.0035, 0.008):
        lam = di.steady_state([CT, 0, 0], 0.0, 0.0, P)
        assert abs(lam[0] - math.sqrt(CT / 2.0)) < 1e-10          # lam_h = sqrt(C_T/2)
        assert abs(lam[1]) < 1e-12 and abs(lam[2]) < 1e-12


def test_climb_steady_equals_momentum():
    CT, lam_c = 0.0035, 0.03
    lam = di.steady_state([CT, 0, 0], lam_c, 0.0, P)
    expected = -lam_c / 2 + math.sqrt((lam_c / 2) ** 2 + CT / 2)   # momentum theory in climb
    assert abs(lam[0] - expected) < 1e-10


def test_forward_flight_steady_equals_glauert():
    """Independent Glauert fixed point: lam_i = C_T / (2 sqrt(mu^2 + (lam_c + lam_i)^2))."""
    for mu, lam_c in [(0.05, 0.0), (0.15, 0.0), (0.2, 0.02), (0.3, 0.05)]:
        CT = 0.0035
        li = math.sqrt(CT / 2)
        for _ in range(500):
            li = 0.5 * li + 0.5 * CT / (2 * math.sqrt(mu ** 2 + (lam_c + li) ** 2))
        lam = di.steady_state([CT, 0, 0], lam_c, mu, P)
        assert abs(lam[0] - li) < 1e-9, (mu, lam_c)


def test_pure_thrust_first_harmonic_ratio():
    """Static P-P, zero moments: lam_c/lam_0 = (15 pi/32) tan(chi/2); lam_s = 0."""
    for mu in (0.05, 0.1, 0.2, 0.3):
        lam = di.steady_state([0.0035, 0, 0], 0.0, mu, P)
        ratio = di.pitt_peters_pure_thrust_ratio(mu, lam[0])
        assert abs(lam[2] / lam[0] - ratio) < 1e-9
        assert abs(lam[1]) < 1e-12 and lam[2] > 0.0               # more inflow aft


def test_dynamic_relaxes_to_static():
    mu, CT = 0.12, 0.0035
    tau = np.array([CT, 0.0008, -0.0004])
    target = di.steady_state(tau, 0.0, mu, P)
    x = di.advance(np.array([0.02, 0.0, 0.0]), tau, OMEGA, 0.0, mu, dt=3.0, p=P)
    assert np.max(np.abs(x - target)) < 1e-8


# ------------------------------------------------------------------ V2
def _hover_numeric(CT1, CT2, t_end, dt, method):
    lam = di.steady_state([CT1, 0, 0], 0.0, 0.0, P)
    n = int(round(t_end / dt))
    for _ in range(n):
        lam = di.step(lam, [CT2, 0, 0], OMEGA, 0.0, 0.0, dt, P, method)
    return lam[0], di.steady_state([CT1, 0, 0], 0.0, 0.0, P)[0]


def test_hover_step_matches_exact_tanh_solution():
    CT1, CT2 = 0.0030, 0.0045                                     # +50 % thrust (nonlinear)
    num, lam_a = _hover_numeric(CT1, CT2, 0.2, 1e-3, "rk4")
    exact = float(di.hover_step_exact(0.2, lam_a, math.sqrt(CT2 / 2), OMEGA, P))
    assert abs(num - exact) < 1e-9


def test_hover_linearised_time_constant():
    """tau = M0 / (4 lam_f Omega): hand calculation vs 1/e time of a small (2 %) thrust step."""
    CT1 = 0.0035
    CT2 = 1.02 * CT1
    lam_f = math.sqrt(CT2 / 2)
    tau_hand = P.M0 / (4.0 * lam_f * OMEGA)
    lam0 = di.steady_state([CT1, 0, 0], 0.0, 0.0, P)
    d0 = lam_f - lam0[0]
    x, t, dt = lam0.copy(), 0.0, tau_hand / 2000.0
    while lam_f - x[0] > d0 / math.e:
        x = di.step(x, [CT2, 0, 0], OMEGA, 0.0, 0.0, dt, P, "rk4")
        t += dt
    assert abs(t - tau_hand) / tau_hand < 0.01
    assert 0.03 < tau_hand < 0.12                                  # ~60 ms at 750 RPM, C_T=3.5e-3


# ------------------------------------------------------------------ V3
def _observed_order(method, dts):
    CT1, CT2, T = 0.0030, 0.0045, 0.3
    lam_a = di.steady_state([CT1, 0, 0], 0.0, 0.0, P)[0]
    exact = float(di.hover_step_exact(T, lam_a, math.sqrt(CT2 / 2), OMEGA, P))
    errs = [abs(_hover_numeric(CT1, CT2, T, dt, method)[0] - exact) for dt in dts]
    return errs, [math.log2(errs[i] / errs[i + 1]) for i in range(len(errs) - 1)]


def test_dt_convergence_euler_first_order():
    errs, orders = _observed_order("euler", [0.02, 0.01, 0.005, 0.0025])
    assert all(errs[i] > errs[i + 1] for i in range(len(errs) - 1)), errs
    assert 0.85 < orders[-1] < 1.2, orders


def test_dt_convergence_implicit_at_least_first_order():
    """Frozen-L backward Euler is formally 1st order; on the hover Riccati equation
    (u' = a - b u^2) its O(h^2) error term cancels, so ~2nd order is observed. Require >= 1."""
    errs, orders = _observed_order("implicit", [0.02, 0.01, 0.005, 0.0025])
    assert all(errs[i] > errs[i + 1] for i in range(len(errs) - 1)), errs
    assert orders[-1] > 0.9, orders


def test_dt_convergence_rk4_fourth_order():
    errs, orders = _observed_order("rk4", [0.08, 0.04, 0.02, 0.01])
    assert 3.6 < orders[-1] < 4.5, orders


# ------------------------------------------------------------------ V4
def test_large_dt_is_stable_and_exact():
    """Mission-planner dt = 1 s >> tau ~ 60 ms: substepping must keep RK4 stable and exact."""
    CT1, CT2 = 0.0030, 0.0045
    lam = di.steady_state([CT1, 0, 0], 0.0, 0.0, P)
    for method in ("rk4", "implicit"):
        out = di.advance(lam, [CT2, 0, 0], OMEGA, 0.0, 0.0, dt=1.0, p=P, method=method,
                         max_substep_s=1e-3 if method == "implicit" else None)
        exact = float(di.hover_step_exact(1.0, lam[0], math.sqrt(CT2 / 2), OMEGA, P))
        assert np.all(np.isfinite(out)) and abs(out[0] - exact) < 1e-6, method


def test_inflow_lags_a_thrust_step():
    CT1, CT2 = 0.0030, 0.0045
    lam = di.steady_state([CT1, 0, 0], 0.0, 0.0, P)
    out = di.advance(lam, [CT2, 0, 0], OMEGA, 0.0, 0.0, dt=0.02, p=P)
    assert lam[0] < out[0] < math.sqrt(CT2 / 2)                   # inflow lags the new thrust


def test_modes_are_stable_over_envelope():
    for mu in np.linspace(0.0, 0.4, 9):
        for lam0 in np.linspace(0.02, 0.1, 9):
            L = di.L_matrix(np.array([lam0, 0, 0]), 0.0, mu, P)
            A = np.linalg.inv(L) / P.mass_diag()[:, None]
            assert np.all(np.linalg.eigvals(A).real > 0.0), (mu, lam0)


def test_zero_thrust_and_zero_speed_are_finite():
    lam = di.steady_state([0.0, 0, 0], 0.0, 0.0, P)
    assert np.all(np.isfinite(lam))
    x = di.advance(lam, [0.0, 0, 0], OMEGA, 0.0, 0.0, 0.1, P)
    assert np.all(np.isfinite(x))


def test_baseline_ratio_helpers_are_comparable():
    """Static P-P vs the repo's Drees correction: same functional role, report the gap."""
    mu = 0.15
    lam = di.steady_state([0.0035, 0, 0], 0.0, mu, P)
    k_pp = di.pitt_peters_pure_thrust_ratio(mu, lam[0])
    k_dr = di.drees_first_harmonic_ratio(mu, lam[0])
    assert k_pp > 0 and k_dr > 0 and 0.2 < k_pp / k_dr < 5.0


def test_sign_convention_inflow_follows_loading():
    """Loading toward +y_R (psi=90) -> more inflow at psi=90; aft loading (+x_R) -> more inflow at psi=0.
    Must hold for both rotation senses (M_hub_rotor is geometric)."""
    base = dict(T=3000.0, rho=1.225, Vtip=200.0)
    R = 2.6
    q = base["rho"] * math.pi * R ** 2 * base["Vtip"] ** 2
    for s in (+1.0, -1.0):
        # load on the +y_R side  -> moment about +x_R is positive (r x F, F along +z_R)
        res = dict(base, M_hub_rotor=np.array([+500.0, 0.0, 0.0]))
        tau = di.forcing_from_edgewise_result(res, R, s)
        lam = di.steady_state(tau, 0.0, 0.1, P)
        i90 = di.inflow_at(lam, 1.0, math.pi / 2, s)
        i270 = di.inflow_at(lam, 1.0, 3 * math.pi / 2, s)
        assert i90 > i270, s
        # aft loading (+x_R) -> moment about +y_R is negative
        res = dict(base, M_hub_rotor=np.array([0.0, -500.0, 0.0]))
        tau = di.forcing_from_edgewise_result(res, R, s)
        lam = di.steady_state(tau, 0.0, 0.1, P)
        assert di.inflow_at(lam, 1.0, 0.0, s) > di.inflow_at(lam, 1.0, math.pi, s), s
    assert abs(tau[0] - base["T"] / q) < 1e-15


if __name__ == "__main__":
    fails = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn(); print("PASS", name)
            except Exception as e:                                  # noqa: BLE001
                fails += 1; print("FAIL", name, repr(e))
    sys.exit(1 if fails else 0)
