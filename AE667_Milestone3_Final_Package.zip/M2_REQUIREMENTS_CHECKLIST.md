# Milestone 2 Requirements Checklist

This checklist is based on the re-uploaded Milestone 2 requirements PDF.

## Core tasks

- [x] Task 1 — inertial/body/rotor-shaft/TPP/blade-element frames, azimuth and transformation chain.
- [x] Task 2 — radial/azimuth discretization, edgewise velocity, rigid-disk assumption, induced inflow, cyclic pitch, nacelle tilt, revolution integration.
- [x] Task 3 — advancing/retreating asymmetry, reverse flow, advancing-tip Mach, stall flag, non-uniform inflow.
- [x] Task 4 — rotor-frame and body-frame time-averaged loads plus hub-placement moment about CG; opposite rotor rotation signs cancel steady reaction torque.
- [x] Task 5 — collective, longitudinal cyclic and lateral cyclic sweeps with FX/FY/FZ, MX/MY/MZ, rotor power and feasibility margins at two conditions.
- [x] Task 6 — wing, fuselage/nacelle and empennage model with component velocity/AoA dependence and stated interference omission.
- [x] Task 7 — bounded numerical steady trim; all six aircraft loads appear in the residual/result vector; convergence and physical feasibility are separate.
- [x] Task 8 — resolved speed/nacelle-angle feasibility map seeded from the required trim matrix; active-constraint overlays and summary.
- [x] Task 9 — user-input-driven transition mission engine; outbound and inbound examples use the same aircraft configuration and record the specified time histories.
- [x] Task 10 — design-refinement rationale plus integrated M1-vs-M2 assessment and M3 development plan.

## Demonstration requirements

- [x] Control response at one helicopter-like condition.
- [x] Control response at one intermediate conversion condition.
- [x] Trim matrix has 3 nacelle angles × 3 airspeeds.
- [x] Complete takeoff/initial-climb → airplane-mode conversion example.
- [x] Complete airplane-mode → hover/descent conversion example.

## Section 2 algorithm evidence

- [x] Edgewise estimator flow diagram + written explanation.
- [x] Trim-solver flow diagram + unknowns/residual/convergence explanation.
- [x] Mission Planner v2 flow diagram + state/fuel/feasibility explanation.

## Section 3 verification evidence

- [x] M1 hover limiting case recovered at V_edge=0, cyclic=0.
- [x] M1 axial forward-flight limiting case recovered at V_edge=0, cyclic=0.
- [x] Azimuthal sectional-thrust contour with operating condition stated.
- [x] In-plane velocity/reverse-flow boundary with operating condition stated.
- [x] α=±12° stall boundaries plus advancing-tip Mach check.
- [x] Four numerical sensitivity plots: T/Q versus radial stations and T/Q versus azimuth stations.

## Section 4 control-response evidence

- [x] Collective sweep: all six load components, power, stall/Mach/reverse-flow margins.
- [x] Longitudinal cyclic sweep: all six load components and power.
- [x] Lateral cyclic sweep: all six load components and power.
- [x] Physical interpretation of cyclic coupling explicitly written.

## Section 5/6/7/8 evidence

- [x] Updated aircraft schematic and component/reference locations.
- [x] Summary of design changes from M1.
- [x] Updated rotor table.
- [x] Wing and empennage table.
- [x] Mass/CG/control-limit table.
- [x] 3×3 trim matrix and full trim-results CSV.
- [x] Failed/rejected trim case classified by the governing constraint.
- [x] Physical interpretation of trim trends.
- [x] Resolved speed–nacelle-angle map with fixed altitude/mass/atmosphere noted.
- [x] Active-constraint map/summary.
- [x] Outbound and inbound transition inputs and histories.

## Code-package requirements

- [x] README.
- [x] Dependency/environment files.
- [x] Example inputs.
- [x] Validation data.
- [x] M1 regression tests.
- [x] Scripts to reproduce graded figures/tables.
- [x] Modular atmosphere/airfoil/geometry/inflow/blade-load/rotor/trim/mission components.
- [x] Units/sign/reference-frame conventions documented.
- [x] Nonphysical-input and convergence checks.
- [x] No hard-coded single mission in the mission engine.
- [x] AI assistance acknowledged.
