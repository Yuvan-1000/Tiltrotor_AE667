"""AE 667 Milestone 3 final-design performance and end-to-end mission run.

This driver freezes the M2 aircraft configuration, re-solves the selected
40 m/s airplane-mode cruise trim on the same 80x12 grid used by the mission,
constructs one vertical-takeoff-to-vertical-landing mission, runs the existing
M2 MissionPlannerV2 in static-inflow mode, and regenerates M3 outputs/figures.

Run from this directory:
    python run_m3_final.py
"""
from __future__ import annotations
import csv
import json
import math
from pathlib import Path
from typing import Any

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.optimize import brentq

from aircraft_config import AIRCRAFT, ROTOR, TILTROTOR_GEOM, TILTROTOR_AIRFOIL, G
from bemt_solver import Atmosphere, BEMTSolver, FlightCondition
from trim_solver import SteadyTrimSolver, TrimCase
from mission_planner_v2 import MissionPlannerV2, save_history_csv

ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "inputs"
OUTPUT = ROOT / "outputs"
FIG = ROOT / "figures"
DATA = ROOT / "data"
for d in (INPUT, OUTPUT, FIG, DATA):
    d.mkdir(parents=True, exist_ok=True)

M3_SETTINGS_PATH = INPUT / "m3_mission_settings.json"
if not M3_SETTINGS_PATH.is_file():
    raise FileNotFoundError(f"Missing M3 mission settings: {M3_SETTINGS_PATH}")
M3_SETTINGS = json.loads(M3_SETTINGS_PATH.read_text(encoding="utf-8"))
SIM_SETTINGS = M3_SETTINGS["simulation"]
ENV_SETTINGS = M3_SETTINGS["environment"]
HOVER_SETTINGS = M3_SETTINGS["hover"]
CRUISE_SETTINGS = M3_SETTINGS["cruise"]
SEGMENT_SETTINGS = M3_SETTINGS["mission_segments"]
CONTROL_SETTINGS = M3_SETTINGS["controls"]
CONVERSION_SETTINGS = M3_SETTINGS["conversion_inputs"]

MISSION_GRID_RADIAL = int(SIM_SETTINGS["radial_stations"])
MISSION_GRID_AZIMUTH = int(SIM_SETTINGS["azimuth_stations"])
MISSION_DT_S = float(SIM_SETTINGS["time_step_s"])
INFLOW_MODEL = str(SIM_SETTINGS.get("inflow_model", "static"))
if INFLOW_MODEL != "static":
    raise ValueError("The graded M3 mission is configured for the static M2 baseline; keep inflow_model='static'.")
ISA_TEMPERATURE_OFFSET_K = float(ENV_SETTINGS.get("isa_temperature_offset_K", 0.0))
TRIM_SETTINGS = M3_SETTINGS.get("trim_solver", {"max_iterations": 20, "scaled_residual_tolerance": 1e-4})
MISSION_WIND_MS = float(ENV_SETTINGS.get("wind_ms", 0.0))
HOVER_ALTITUDE_M = float(HOVER_SETTINGS["altitude_m"])
HOVER_RPM = float(HOVER_SETTINGS.get("rpm", ROTOR.rpm_hover))
HOVER_COLLECTIVE_BOUNDS_DEG = tuple(float(x) for x in HOVER_SETTINGS.get("collective_bounds_deg", [ROTOR.collective_hover_deg_min, ROTOR.collective_hover_deg_max]))
CRUISE_SPEED_MS = float(CRUISE_SETTINGS["airspeed_ms"])
CRUISE_ALTITUDE_M = float(CRUISE_SETTINGS["altitude_m"])
CRUISE_DISTANCE_M = float(CRUISE_SETTINGS["distance_m"])
CRUISE_RPM = float(CRUISE_SETTINGS.get("rpm", ROTOR.rpm_cruise))
CRUISE_DURATION_S = CRUISE_DISTANCE_M / CRUISE_SPEED_MS
CRUISE_SEGMENT_DURATIONS_S = [float(x) for x in CRUISE_SETTINGS.get("segment_durations_s", [CRUISE_DURATION_S])]
if not CRUISE_SEGMENT_DURATIONS_S or not math.isclose(sum(CRUISE_SEGMENT_DURATIONS_S), CRUISE_DURATION_S, rel_tol=0.0, abs_tol=max(MISSION_DT_S, 1e-6)):
    raise ValueError("cruise.segment_durations_s must sum to distance_m / airspeed_ms within one simulation time step")


def write_json(path: Path, obj: Any) -> None:
    path.write_text(json.dumps(obj, indent=2), encoding="utf-8")


def make_control_dict(pitch, collective, lateral=0.0, longitudinal=0.0,
                      elevator=0.0, rudder=0.0, aileron=0.0):
    return {
        "pitch_deg": pitch,
        "collective_deg": collective,
        "theta_1c_lateral_deg": lateral,
        "theta_1s_longitudinal_deg": longitudinal,
        "elevator_deg": elevator,
        "rudder_deg": rudder,
        "aileron_deg": aileron,
    }


def hover_performance() -> dict[str, float]:
    """M1 axial BEMT hover point: each rotor carries half MTOW weight."""
    solver = BEMTSolver(TILTROTOR_GEOM, TILTROTOR_AIRFOIL)
    target_per_rotor = AIRCRAFT.gross_weight_kg * G / 2.0

    def residual(collective_deg: float) -> float:
        result = solver.solve(FlightCondition.from_rpm(
            HOVER_RPM, collective_deg, altitude=HOVER_ALTITUDE_M,
            dT_isa=ISA_TEMPERATURE_OFFSET_K,
        ))
        return float(result["T"] - target_per_rotor)

    collective = float(brentq(residual, *HOVER_COLLECTIVE_BOUNDS_DEG, xtol=1e-8))
    result = solver.solve(FlightCondition.from_rpm(
        HOVER_RPM, collective, altitude=HOVER_ALTITUDE_M,
        dT_isa=ISA_TEMPERATURE_OFFSET_K,
    ))
    total_shaft_power = 2.0 * float(result["P"]) / AIRCRAFT.drivetrain_efficiency
    rho, _, _, _, _ = Atmosphere(HOVER_ALTITUDE_M, ISA_TEMPERATURE_OFFSET_K).properties()
    available = AIRCRAFT.n_engines * AIRCRAFT.sea_level_power_per_engine_kW * 1000.0 * (rho / 1.225)
    return {
        "gross_mass_kg": AIRCRAFT.gross_weight_kg,
        "altitude_m": HOVER_ALTITUDE_M,
        "rpm": HOVER_RPM,
        "collective_deg": collective,
        "thrust_per_rotor_N": float(result["T"]),
        "required_thrust_per_rotor_N": target_per_rotor,
        "torque_per_rotor_Nm": float(result["Q"]),
        "power_per_rotor_aero_kW": float(result["P"]) / 1000.0,
        "total_shaft_power_required_kW": total_shaft_power / 1000.0,
        "power_available_kW": available / 1000.0,
        "power_margin_kW": (available - total_shaft_power) / 1000.0,
        "figure_of_merit": float(result.get("FM", np.nan)),
        "CT": float(result["CT"]),
        "tip_mach": float(result.get("M_tip", ROTOR.rpm_hover * 2 * math.pi / 60 * ROTOR.R / 340.3)),
        "stall_fraction": float(result.get("stall_fraction", 0.0)),
    }


def solve_cruise_trim(gross_mass_kg: float = AIRCRAFT.gross_weight_kg, x0=None) -> tuple[dict[str, float], Any]:
    """Re-solve the configured airplane-mode cruise point at a specified mass."""
    solver = SteadyTrimSolver(
        radial_stations=MISSION_GRID_RADIAL,
        n_azimuth=MISSION_GRID_AZIMUTH,
        max_iter=int(TRIM_SETTINGS.get("max_iterations", 20)),
        tol=float(TRIM_SETTINGS.get("scaled_residual_tolerance", 1e-4)),
    )
    case = TrimCase(
        nacelle_angle_deg=0.0,
        airspeed_ms=CRUISE_SPEED_MS,
        altitude_m=CRUISE_ALTITUDE_M,
        gross_weight_kg=float(gross_mass_kg),
        dT_isa=ISA_TEMPERATURE_OFFSET_K,
        wind_ms=MISSION_WIND_MS,
        climb_rate_ms=0.0,
        rpm=CRUISE_RPM,
    )
    x0 = list(x0) if x0 is not None else list(CRUISE_SETTINGS.get("initial_trim_guess", [3.5855, 31.4342, 2.8311, 0.0, 0.2335, 0.0, 0.0]))
    solved = solver.solve(case, x0=x0)
    if not solved["success"] or not solved["physical_feasible"]:
        raise RuntimeError(
            f"M3 cruise trim did not pass: numerical={solved['success']}, "
            f"physical={solved['physical_feasible']}, residual={solved['max_scaled_residual']:.4g}"
        )
    o = solved["loads_dict"]
    wing_lift = float(o["wing"]["L"])
    tail_lift = float(o["tail"]["L"])
    total_aero_drag = float(o["wing"]["D"] + o["tail"]["D"] + o["drag"]["D"])
    total_lift = wing_lift + tail_lift
    total_aero_power = float(o["P_required_W"] * AIRCRAFT.drivetrain_efficiency)
    ld = total_lift / total_aero_drag if total_aero_drag > 0 else np.nan
    eta_p = total_aero_drag * CRUISE_SPEED_MS / total_aero_power if total_aero_power > 0 else np.nan
    x = solved["x"]
    metrics = {
        "gross_mass_kg": float(gross_mass_kg),
        "altitude_m": CRUISE_ALTITUDE_M,
        "airspeed_ms": CRUISE_SPEED_MS,
        "airspeed_kt": CRUISE_SPEED_MS * 1.943844492,
        "nacelle_angle_deg": 0.0,
        "rpm": CRUISE_RPM,
        "pitch_deg": float(x[0]),
        "collective_deg": float(x[1]),
        "theta_1c_lateral_deg": float(x[2]),
        "theta_1s_longitudinal_deg": float(x[3]),
        "elevator_deg": float(x[4]),
        "rudder_deg": float(x[5]),
        "aileron_deg": float(x[6]),
        "power_required_kW": float(o["P_required_W"] / 1000.0),
        "power_available_kW": float(o["P_available_W"] / 1000.0),
        "power_margin_kW": float((o["P_available_W"] - o["P_required_W"]) / 1000.0),
        "power_margin_pct_of_available": float((o["P_available_W"] - o["P_required_W"]) / o["P_available_W"] * 100.0),
        "wing_lift_N": wing_lift,
        "tail_lift_N": tail_lift,
        "total_lift_N": total_lift,
        "wing_drag_N": float(o["wing"]["D"]),
        "tail_drag_N": float(o["tail"]["D"]),
        "fuselage_nacelle_drag_N": float(o["drag"]["D"]),
        "total_aero_drag_N": total_aero_drag,
        "aircraft_L_over_D_estimate": float(ld),
        "propulsive_efficiency_estimate": float(eta_p),
        "wing_CL": float(o["wing"]["CL"]),
        "wing_CD": float(o["wing"]["CD"]),
        "wing_CL_margin_to_CLmax": float(AIRCRAFT.wing_cl_max - abs(o["wing"]["CL"])),
        "advancing_tip_mach": float(o["rotor"]["M_adv"]),
        "tip_mach_margin": float(ROTOR.tip_mach_limit - o["rotor"]["M_adv"]),
        "stalled_span_pct": float(o["rotor"]["stall_span"] * 100.0),
        "rotor_stall_margin_percentage_points": float((ROTOR.stall_span_fraction_limit - o["rotor"]["stall_span"]) * 100.0),
        "reverse_flow_pct": float(o["rotor"]["reverse_flow_fraction"] * 100.0),
        "max_scaled_trim_residual": float(solved["max_scaled_residual"]),
        "numerically_converged": bool(solved["success"]),
        "physically_feasible": bool(solved["physical_feasible"]),
    }
    return metrics, solved


def build_final_mission(cruise_trim: dict[str, float], cruise_part_trims: list[dict[str, float]] | None = None) -> dict[str, Any]:
    """Build a configurable vertical-takeoff / conversion / cruise / landing mission.

    The M2 conversion waypoint schedules are reused verbatim except for the
    global wind and ISA temperature offset selected in m3_mission_settings.json.
    Final aircraft and M3 mission assumptions are read from the two JSON inputs.
    """
    outbound_name = str(CONVERSION_SETTINGS["outbound_file"])
    inbound_name = str(CONVERSION_SETTINGS["inbound_file"])
    base_out = json.loads((INPUT / outbound_name).read_text(encoding="utf-8"))
    base_in = json.loads((INPUT / inbound_name).read_text(encoding="utf-8"))
    start_idx, end_idx = [int(x) for x in CONVERSION_SETTINGS.get("transition_segment_slice", [1, 9])]
    outbound_transition = json.loads(json.dumps(base_out["segments"][start_idx:end_idx]))
    inbound_transition = json.loads(json.dumps(base_in["segments"][start_idx:end_idx]))
    for i, seg in enumerate(outbound_transition, 1):
        seg["name"] = f"outbound_conversion_{i:02d}"
    for i, seg in enumerate(inbound_transition, 1):
        seg["name"] = f"inbound_conversion_{i:02d}"
    for seg in outbound_transition + inbound_transition:
        seg["wind_ms"] = MISSION_WIND_MS
        seg["dT_isa"] = ISA_TEMPERATURE_OFFSET_K

    cruise_part_trims = cruise_part_trims or [cruise_trim] * len(CRUISE_SEGMENT_DURATIONS_S)
    if len(cruise_part_trims) != len(CRUISE_SEGMENT_DURATIONS_S):
        raise ValueError("Number of cruise trim records must match cruise.segment_durations_s")
    cruise_control_dicts = [make_control_dict(
        item["pitch_deg"], item["collective_deg"],
        item["theta_1c_lateral_deg"], item["theta_1s_longitudinal_deg"],
        item["elevator_deg"], item["rudder_deg"], item["aileron_deg"],
    ) for item in cruise_part_trims]
    cruise_controls = cruise_control_dicts[0]
    last_cruise_controls = cruise_control_dicts[-1]
    transition_start_controls = make_control_dict(
        float(CONTROL_SETTINGS["conversion_start_pitch_deg"]),
        float(CONTROL_SETTINGS["conversion_start_collective_deg"]),
    )

    takeoff_altitude = float(AIRCRAFT.takeoff_altitude_m)
    cruise_altitude = CRUISE_ALTITUDE_M
    hover_collective = float(CONTROL_SETTINGS["hover_collective_deg"])
    dt = MISSION_DT_S
    mission = {
        "mission_name": str(M3_SETTINGS["mission_name"]),
        "description": str(M3_SETTINGS["description"]),
        "initial_fuel_kg": float(AIRCRAFT.fuel_capacity_kg),
        "gross_weight_kg": float(AIRCRAFT.gross_weight_kg),
        "payload_kg": float(AIRCRAFT.max_payload_kg),
        "wind_ms": MISSION_WIND_MS,
        "dT_isa": ISA_TEMPERATURE_OFFSET_K,
        "atmosphere": f"{ENV_SETTINGS.get('atmosphere_model', 'ISA')}, delta ISA={ISA_TEMPERATURE_OFFSET_K:+.1f} K; cruise altitude {cruise_altitude:.0f} m",
        "reserve_fuel_kg": mission_reserve(),
        "dt_s": dt,
        "inflow_model": "static M2 baseline",
        "radial_stations": MISSION_GRID_RADIAL,
        "azimuth_stations": MISSION_GRID_AZIMUTH,
        "segments": [
            {
                "name": "pre_takeoff_hover",
                "duration_s": float(SEGMENT_SETTINGS["pre_takeoff_hover_duration_s"]),
                "airspeed_ms": 0.0,
                "altitude_m": takeoff_altitude,
                "nacelle_angle_deg": 90.0,
                "rpm": HOVER_RPM,
                "climb_rate_ms": 0.0,
                "wind_ms": MISSION_WIND_MS,
                "dT_isa": ISA_TEMPERATURE_OFFSET_K,
                "control_source": "scheduled",
                "enforce_trim": False,
                "controls": make_control_dict(0.0, hover_collective),
            },
            {
                "name": "vertical_takeoff_and_climb",
                "duration_s": float(SEGMENT_SETTINGS["vertical_climb_duration_s"]),
                "airspeed_ms": [float(SEGMENT_SETTINGS["initial_climb_speed_ms"]), float(SEGMENT_SETTINGS["terminal_climb_speed_ms"])],
                "altitude_m": [takeoff_altitude, cruise_altitude],
                "nacelle_angle_deg": [90.0, 90.0],
                "rpm": [HOVER_RPM, HOVER_RPM],
                "climb_rate_ms": float(SEGMENT_SETTINGS["vertical_climb_rate_ms"]),
                "wind_ms": MISSION_WIND_MS,
                "dT_isa": ISA_TEMPERATURE_OFFSET_K,
                "control_source": "scheduled",
                "enforce_trim": False,
                "controls": make_control_dict([0.0, 0.0], [hover_collective, hover_collective]),
            },
            *outbound_transition,
            {
                "name": "acceleration_to_cruise",
                "duration_s": float(SEGMENT_SETTINGS["acceleration_duration_s"]),
                "airspeed_ms": [float(SEGMENT_SETTINGS.get("acceleration_start_speed_ms", 35.0)), CRUISE_SPEED_MS],
                "altitude_m": [cruise_altitude, cruise_altitude],
                "nacelle_angle_deg": [0.0, 0.0],
                "rpm": [CRUISE_RPM, CRUISE_RPM],
                "climb_rate_ms": 0.0,
                "wind_ms": MISSION_WIND_MS,
                "dT_isa": ISA_TEMPERATURE_OFFSET_K,
                "control_source": "scheduled",
                "enforce_trim": False,
                "controls": {k: [transition_start_controls[k], cruise_controls[k]] for k in cruise_controls},
            },
            *[
                {
                    "name": f"airplane_mode_cruise_part{i+1:02d}",
                    "duration_s": duration,
                    "airspeed_ms": CRUISE_SPEED_MS,
                    "altitude_m": cruise_altitude,
                    "nacelle_angle_deg": 0.0,
                    "rpm": CRUISE_RPM,
                    "climb_rate_ms": 0.0,
                    "wind_ms": MISSION_WIND_MS,
                    "dT_isa": ISA_TEMPERATURE_OFFSET_K,
                    "control_source": "scheduled",
                    "enforce_trim": True,
                    "controls": cruise_control_dicts[i],
                    "trim_mass_reference_kg": cruise_part_trims[i]["gross_mass_kg"],
                }
                for i, duration in enumerate(CRUISE_SEGMENT_DURATIONS_S)
            ],
            {
                "name": "deceleration_before_reconversion",
                "duration_s": float(SEGMENT_SETTINGS["deceleration_duration_s"]),
                "airspeed_ms": [CRUISE_SPEED_MS, float(SEGMENT_SETTINGS.get("deceleration_end_speed_ms", 35.0))],
                "altitude_m": [cruise_altitude, cruise_altitude],
                "nacelle_angle_deg": [0.0, 0.0],
                "rpm": [CRUISE_RPM, CRUISE_RPM],
                "climb_rate_ms": 0.0,
                "wind_ms": MISSION_WIND_MS,
                "dT_isa": ISA_TEMPERATURE_OFFSET_K,
                "control_source": "scheduled",
                "enforce_trim": False,
                "controls": {k: [last_cruise_controls[k], transition_start_controls[k]] for k in transition_start_controls},
            },
            *inbound_transition,
            {
                "name": "vertical_descent_and_landing_approach",
                "duration_s": float(SEGMENT_SETTINGS["vertical_descent_duration_s"]),
                "airspeed_ms": [float(SEGMENT_SETTINGS["initial_descent_speed_ms"]), float(SEGMENT_SETTINGS["terminal_descent_speed_ms"])],
                "altitude_m": [cruise_altitude, takeoff_altitude],
                "nacelle_angle_deg": [90.0, 90.0],
                "rpm": [HOVER_RPM, HOVER_RPM],
                "climb_rate_ms": float(SEGMENT_SETTINGS["vertical_descent_rate_ms"]),
                "wind_ms": MISSION_WIND_MS,
                "dT_isa": ISA_TEMPERATURE_OFFSET_K,
                "control_source": "scheduled",
                "enforce_trim": False,
                "controls": make_control_dict([0.0, 0.0], [hover_collective, hover_collective]),
            },
            {
                "name": "landing_hover_and_touchdown",
                "duration_s": float(SEGMENT_SETTINGS["landing_hover_duration_s"]),
                "airspeed_ms": 0.0,
                "altitude_m": takeoff_altitude,
                "nacelle_angle_deg": 90.0,
                "rpm": HOVER_RPM,
                "climb_rate_ms": 0.0,
                "wind_ms": MISSION_WIND_MS,
                "dT_isa": ISA_TEMPERATURE_OFFSET_K,
                "control_source": "scheduled",
                "enforce_trim": False,
                "controls": make_control_dict(0.0, hover_collective),
            },
        ],
    }
    return mission


def augment_history_with_distance(history: list[dict[str, Any]], mission: dict[str, Any]) -> list[dict[str, Any]]:
    """Add cumulative distance while retaining segment-boundary time samples."""
    out: list[dict[str, Any]] = []
    ptr = 0
    elapsed = 0.0
    distance_m = 0.0
    dt = float(mission.get("dt_s", 1.0))
    for seg in mission["segments"]:
        duration = float(seg["duration_s"])
        nsteps = int(math.ceil(duration / dt))
        seg_rows = history[ptr:ptr + nsteps + 1]
        if len(seg_rows) != nsteps + 1:
            raise RuntimeError(f"history row count mismatch in {seg['name']}: {len(seg_rows)} != {nsteps+1}")
        for j, raw in enumerate(seg_rows):
            row = dict(raw)
            row["time_s"] = elapsed + min(j * dt, duration)
            row["cumulative_distance_km"] = distance_m / 1000.0
            row["power_margin_kW"] = row["P_available_kW"] - row["P_required_kW"]
            row["power_margin_pct"] = 100.0 * row["power_margin_kW"] / row["P_available_kW"] if row["P_available_kW"] > 0 else -np.inf
            row["fuel_margin_to_reserve_kg"] = row["fuel_remaining_kg"] - mission["reserve_fuel_kg"]
            out.append(row)
            if j < nsteps:
                step_dt = min(dt, duration - j * dt)
                distance_m += float(row["ground_speed_ms"]) * step_dt
        ptr += nsteps + 1
        elapsed += duration
    if ptr != len(history):
        raise RuntimeError(f"unconsumed mission history rows: consumed={ptr}, actual={len(history)}")
    return out


def write_history(path: Path, history: list[dict[str, Any]]) -> None:
    fields = list(history[0].keys())
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(history)


def summarize_mission(history: list[dict[str, Any]], mission: dict[str, Any], result: dict[str, Any]) -> dict[str, Any]:
    seg_names = [s["name"] for s in mission["segments"]]
    summary_rows = []
    for name in seg_names:
        rows = [r for r in history if r["segment"] == name]
        if not rows:
            continue
        last = rows[-1]
        summary_rows.append({
            "segment": name,
            "end_time_s": last["time_s"],
            "end_time_min": last["time_s"] / 60.0,
            "end_altitude_m": last["altitude_m"],
            "end_airspeed_ms": last["airspeed_ms"],
            "end_ground_speed_ms": last["ground_speed_ms"],
            "end_distance_km": last["cumulative_distance_km"],
            "end_gross_mass_kg": last["gross_weight_kg"],
            "end_fuel_kg": last["fuel_remaining_kg"],
            "end_nacelle_deg": last["nacelle_angle_deg"],
            "end_rpm": last["rpm"],
            "power_required_kW": last["P_required_kW"],
            "power_available_kW": last["P_available_kW"],
            "power_margin_kW": last["power_margin_kW"],
            "feasible": all(bool(r["feasible"]) for r in rows),
        })
    fuel_burn = float(mission["initial_fuel_kg"] - result["final_fuel_kg"])
    p_margin = np.array([r["power_margin_pct"] for r in history], dtype=float)
    stall_margin = np.array([r["stall_margin_pct"] for r in history], dtype=float)
    stall_warning_margin = np.array([r["stall_margin_to_warning_pp"] for r in history], dtype=float)
    stalled_span = np.array([r["stalled_span_pct"] for r in history], dtype=float)
    mach_margin = np.array([r["tip_mach_margin"] for r in history], dtype=float)
    reserve_margin = np.array([r["fuel_margin_to_reserve_kg"] for r in history], dtype=float)
    # Normalize each hard-limit margin to compare the governing limit fairly.
    stall_rel = stall_margin / (ROTOR.stall_span_fraction_limit * 100.0) * 100.0
    mach_rel = mach_margin / ROTOR.tip_mach_limit * 100.0
    reserve_rel = reserve_margin / AIRCRAFT.fuel_capacity_kg * 100.0
    limits = {
        "power_margin_pct": float(np.min(p_margin)),
        "rotor_stall_margin_pct_of_limit": float(np.min(stall_rel)),
        "tip_mach_margin_pct_of_limit": float(np.min(mach_rel)),
        "fuel_above_reserve_pct_of_capacity": float(np.min(reserve_rel)),
    }
    min_power_idx = int(np.argmin(p_margin))
    min_stall_idx = int(np.argmin(stall_margin))
    min_mach_idx = int(np.argmin(mach_margin))
    min_reserve_idx = int(np.argmin(reserve_margin))
    return {
        "success": bool(result["success"]),
        "failure": result["failure"],
        "mission_time_s": float(history[-1]["time_s"]),
        "mission_time_min": float(history[-1]["time_s"] / 60.0),
        "total_distance_km": float(history[-1]["cumulative_distance_km"]),
        "cruise_leg_distance_km": CRUISE_DISTANCE_M / 1000.0,
        "fuel_initial_kg": float(mission["initial_fuel_kg"]),
        "fuel_final_kg": float(result["final_fuel_kg"]),
        "fuel_burn_kg": fuel_burn,
        "fuel_reserve_kg": float(mission["reserve_fuel_kg"]),
        "fuel_above_reserve_kg": float(result["final_fuel_kg"] - mission["reserve_fuel_kg"]),
        "landing_mass_kg": float(result["final_gross_weight_kg"]),
        "max_power_required_kW": float(max(r["P_required_kW"] for r in history)),
        "min_power_available_kW": float(min(r["P_available_kW"] for r in history)),
        "minimum_power_margin_pct": limits["power_margin_pct"],
        "minimum_stall_margin_to_hard_limit_percentage_points": float(np.min(stall_margin)),
        "minimum_stall_margin_to_warning_percentage_points": float(np.min(stall_warning_margin)),
        "maximum_stalled_span_pct": float(np.max(stalled_span)),
        "stall_warning_threshold_pct": ROTOR.stall_span_fraction_warning * 100.0,
        "stall_hard_limit_pct": ROTOR.stall_span_fraction_limit * 100.0,
        "stall_warning_threshold_exceeded": bool(np.min(stall_warning_margin) < 0.0),
        "minimum_tip_mach_margin": float(np.min(mach_margin)),
        "minimum_fuel_margin_to_reserve_kg": float(np.min(reserve_margin)),
        "minimum_relative_limit_margin_pct": float(min(limits.values())),
        "limiting_constraint": "power availability" if limits["power_margin_pct"] == min(limits.values()) else min(limits, key=limits.get),
        "limiting_power_point": {k: history[min_power_idx][k] for k in ("segment", "time_s", "airspeed_ms", "nacelle_angle_deg", "rpm", "P_required_kW", "P_available_kW", "power_margin_pct")},
        "minimum_stall_point": {k: history[min_stall_idx][k] for k in ("segment", "time_s", "stall_margin_pct", "airspeed_ms", "nacelle_angle_deg")},
        "minimum_mach_point": {k: history[min_mach_idx][k] for k in ("segment", "time_s", "tip_mach_margin", "airspeed_ms", "nacelle_angle_deg", "rpm")},
        "minimum_reserve_point": {k: history[min_reserve_idx][k] for k in ("segment", "time_s", "fuel_margin_to_reserve_kg")},
        "all_steps_feasible": bool(all(r["feasible"] for r in history)),
        "segment_summary": summary_rows,
    }


def plot_mission(history: list[dict[str, Any]], summary: dict[str, Any]) -> None:
    t_min = np.array([r["time_s"] for r in history]) / 60.0
    segments = np.array([r["segment"] for r in history])
    unique = []
    for s in segments:
        if not unique or unique[-1] != s:
            unique.append(s)
    boundaries = []
    for s in unique[1:]:
        idx = next(i for i, r in enumerate(history) if r["segment"] == s)
        boundaries.append(t_min[idx])

    def mark_boundaries(ax):
        for b in boundaries:
            ax.axvline(b, color="0.65", lw=0.7, ls="--", zorder=0)
        ax.grid(True, alpha=0.25)

    # (a) altitude, air/ground speed, cumulative distance
    fig, axs = plt.subplots(3, 1, figsize=(10.5, 8.2), sharex=True)
    axs[0].plot(t_min, [r["altitude_m"] for r in history], lw=1.5)
    axs[0].set_ylabel("Altitude [m]")
    axs[1].plot(t_min, [r["airspeed_ms"] for r in history], label="Airspeed", lw=1.3)
    axs[1].plot(t_min, [r["ground_speed_ms"] for r in history], label="Ground speed", lw=1.0, ls="--")
    axs[1].set_ylabel("Speed [m/s]"); axs[1].legend(loc="best", fontsize=8)
    axs[2].plot(t_min, [r["cumulative_distance_km"] for r in history], lw=1.5)
    axs[2].set_ylabel("Distance [km]"); axs[2].set_xlabel("Mission time [min]")
    for ax in axs: mark_boundaries(ax)
    fig.suptitle(f"M3 mission: trajectory and distance ({ENV_SETTINGS.get('atmosphere_model', 'ISA')}, wind {MISSION_WIND_MS:.1f} m/s)")
    fig.tight_layout(); fig.savefig(FIG / "m3_mission_trajectory.png", dpi=180); plt.close(fig)

    # (b) mass and fuel
    fig, ax = plt.subplots(figsize=(10.5, 4.5))
    ax.plot(t_min, [r["gross_weight_kg"] for r in history], label="Gross mass", lw=1.5)
    ax.plot(t_min, [r["fuel_remaining_kg"] for r in history], label="Fuel remaining", lw=1.5)
    ax.axhline(mission_reserve(), color="0.3", ls="--", lw=1.0, label="Fuel reserve")
    ax.set_xlabel("Mission time [min]"); ax.set_ylabel("Mass / fuel [kg]")
    mark_boundaries(ax); ax.legend(loc="best", fontsize=8)
    ax.set_title("M3 mission: gross mass and fuel")
    fig.tight_layout(); fig.savefig(FIG / "m3_mission_fuel_mass.png", dpi=180); plt.close(fig)

    # (c) configuration
    fig, axs = plt.subplots(2, 1, figsize=(10.5, 6.0), sharex=True)
    axs[0].plot(t_min, [r["nacelle_angle_deg"] for r in history], lw=1.5)
    axs[0].set_ylabel("Nacelle angle [deg]")
    axs[1].plot(t_min, [r["rpm"] for r in history], lw=1.5)
    axs[1].set_ylabel("Rotor RPM"); axs[1].set_xlabel("Mission time [min]")
    for ax in axs: mark_boundaries(ax)
    fig.suptitle("M3 mission: nacelle conversion and RPM schedule")
    fig.tight_layout(); fig.savefig(FIG / "m3_mission_configuration.png", dpi=180); plt.close(fig)

    # (d) power
    fig, ax = plt.subplots(figsize=(10.5, 4.5))
    ax.plot(t_min, [r["P_required_kW"] for r in history], label="Power required", lw=1.4)
    ax.plot(t_min, [r["P_available_kW"] for r in history], label="Power available", lw=1.2)
    ax.set_xlabel("Mission time [min]"); ax.set_ylabel("Shaft power [kW]")
    mark_boundaries(ax); ax.legend(loc="best", fontsize=8)
    ax.set_title("M3 mission: power required and power available")
    fig.tight_layout(); fig.savefig(FIG / "m3_mission_power.png", dpi=180); plt.close(fig)

    # (e) limits
    fig, axs = plt.subplots(3, 1, figsize=(10.5, 7.4), sharex=True)
    axs[0].plot(t_min, [r["power_margin_pct"] for r in history], lw=1.2)
    axs[0].set_ylabel("Power margin [% of available]")
    axs[1].plot(t_min, [r["stall_margin_pct"] for r in history], lw=1.2)
    axs[1].set_ylabel("Rotor stall margin [pp]")
    axs[2].plot(t_min, [r["tip_mach_margin"] for r in history], lw=1.2)
    axs[2].set_ylabel("Tip-Mach margin [-]"); axs[2].set_xlabel("Mission time [min]")
    for ax in axs: mark_boundaries(ax)
    fig.suptitle("M3 mission: operational margins")
    fig.tight_layout(); fig.savefig(FIG / "m3_mission_margins.png", dpi=180); plt.close(fig)



def plot_design_summaries(hover: dict[str, float], cruise: dict[str, float], mission: dict[str, Any], history: list[dict[str, Any]]) -> None:
    """Generate final-design summary figures used alongside the mission plots."""
    from matplotlib.patches import Rectangle, Circle, Polygon

    # Approximate planform schematic using the frozen M2 geometry.
    fig, ax = plt.subplots(figsize=(10.5, 5.2))
    ax.add_patch(Rectangle((-5.0, -0.65), 10.0, 1.30, fill=False, lw=2.0, label="Fuselage"))
    ax.add_patch(Rectangle((-1.0, -AIRCRAFT.wing_span_m/2), 3.0, AIRCRAFT.wing_span_m, fill=False, lw=1.8, label="Main wing"))
    ax.add_patch(Rectangle((-4.6, -AIRCRAFT.htail_span_m/2), 1.2, AIRCRAFT.htail_span_m, fill=False, lw=1.5, label="Horizontal tail"))
    ax.add_patch(Polygon([(-4.7, -0.35), (-3.6, 0.0), (-4.7, 0.35)], closed=True, fill=False, lw=1.2, label="Vertical tail"))
    for side in (-1, 1):
        hub = (AIRCRAFT.rotor_hub_x_m, side * AIRCRAFT.rotor_half_span_m)
        ax.add_patch(Rectangle((hub[0]-0.8, hub[1]-0.25), 1.6, 0.5, fill=False, lw=1.4))
        ax.add_patch(Circle(hub, ROTOR.R, fill=False, lw=1.4, ls="--"))
        ax.plot(*hub, marker="o", ms=5)
        ax.annotate("tilting nacelle / engine", (hub[0]+0.1, hub[1]+side*0.45), xytext=(hub[0]+1.4, hub[1]+side*1.2),
                    arrowprops={"arrowstyle":"->", "lw":0.8}, fontsize=8)
    ax.add_patch(Rectangle((-1.8, -0.42), 3.2, 0.84, fill=False, lw=1.0, ls=":"))
    ax.text(-0.2, 0.0, "550 kg payload\nregion", ha="center", va="center", fontsize=8)
    ax.plot(AIRCRAFT.cg_x_m, AIRCRAFT.cg_y_m, marker="x", ms=9, mew=2, label="CG")
    # Simple tricycle landing-gear indicators.
    ax.plot([3.7, -2.6, -2.6], [0.0, -2.3, 2.3], marker="s", ls="none", ms=5, label="Landing gear")
    ax.annotate("10 m fuselage (approx.)", xy=(0, -0.68), xytext=(0, -2.0), ha="center", fontsize=8,
                arrowprops={"arrowstyle":"<->", "lw":0.8})
    ax.annotate("12 m wing span", xy=(-1.25, -6.0), xytext=(-2.2, -6.0), fontsize=8, ha="right", va="center",
                arrowprops={"arrowstyle":"<->", "lw":0.8})
    ax.set_aspect("equal", adjustable="box")
    ax.set_xlim(-7.5, 7.5); ax.set_ylim(-7.5, 7.5)
    ax.set_xlabel("Body x [m] (+ forward)"); ax.set_ylabel("Body y [m] (+ starboard)")
    ax.set_title("Frozen M3 tiltrotor configuration — approximate plan view")
    ax.grid(True, alpha=0.2); ax.legend(loc="upper left", fontsize=8, ncol=2)
    fig.tight_layout(); fig.savefig(FIG / "m3_final_aircraft_schematic.png", dpi=180); plt.close(fig)

    # Required and available power at the selected hover and cruise points.
    fig, ax = plt.subplots(figsize=(8.4, 4.8))
    x = np.arange(2); width = 0.34
    req = [hover["total_shaft_power_required_kW"], cruise["power_required_kW"]]
    avail = [hover["power_available_kW"], cruise["power_available_kW"]]
    ax.bar(x-width/2, req, width, label="Power required")
    ax.bar(x+width/2, avail, width, label="Power available")
    ax.set_xticks(x, [f"Hover\n{hover['rpm']:.0f} RPM, sea level", f"Cruise\n{cruise['airspeed_ms']:.0f} m/s, {cruise['altitude_m']:.0f} m"])
    ax.set_ylabel("Shaft power [kW]"); ax.set_title("Selected hover and airplane-mode power points")
    ax.grid(axis="y", alpha=0.25); ax.legend()
    for i, (r, a) in enumerate(zip(req, avail)):
        ax.text(i, max(r,a)+12, f"margin {a-r:.0f} kW", ha="center", fontsize=8)
    fig.tight_layout(); fig.savefig(FIG / "m3_hover_cruise_power.png", dpi=180); plt.close(fig)

    # Dimensionless metrics are displayed with clear labels; they are not interchangeable.
    fig, axs = plt.subplots(1, 3, figsize=(10.5, 4.1))
    axs[0].bar(["Hover FM"], [hover["figure_of_merit"]]); axs[0].set_ylim(0,1); axs[0].set_title("Hover efficiency")
    axs[1].bar(["Aircraft L/D"], [cruise["aircraft_L_over_D_estimate"]]); axs[1].set_title("Cruise aerodynamic efficiency")
    axs[2].bar(["η prop"], [cruise["propulsive_efficiency_estimate"]]); axs[2].set_ylim(0,1); axs[2].set_title("Cruise propulsive estimate")
    for ax in axs: ax.grid(axis="y", alpha=0.2)
    fig.suptitle("Selected dimensionless performance indicators (different definitions)")
    fig.tight_layout(); fig.savefig(FIG / "m3_efficiency_metrics.png", dpi=180); plt.close(fig)

    # Plot the exact waypoint path traversed by the final mission.
    fig, ax = plt.subplots(figsize=(7.5, 5.5))
    outbound = [r for r in history if r["segment"].startswith("outbound_conversion_")]
    inbound = [r for r in history if r["segment"].startswith("inbound_conversion_")]
    ax.plot([r["airspeed_ms"] for r in outbound], [r["nacelle_angle_deg"] for r in outbound], "o-", label="Outbound conversion")
    ax.plot([r["airspeed_ms"] for r in inbound], [r["nacelle_angle_deg"] for r in inbound], "s--", label="Inbound reconversion")
    ax.set_xlabel("Airspeed [m/s]"); ax.set_ylabel("Nacelle angle γ [deg]")
    ax.set_title("M3 mission conversion path (M2 waypoints reused)")
    ax.grid(True, alpha=0.25); ax.legend()
    fig.tight_layout(); fig.savefig(FIG / "m3_conversion_map_path.png", dpi=180); plt.close(fig)

def mission_reserve() -> float:
    return AIRCRAFT.fuel_capacity_kg * AIRCRAFT.reserve_fuel_fraction


def performance_summary(hover: dict[str, float], cruise: dict[str, float], mission: dict[str, Any]) -> dict[str, Any]:
    disk_area_total = AIRCRAFT.n_rotors * math.pi * ROTOR.R**2
    wing_loading = AIRCRAFT.gross_weight_kg * G / AIRCRAFT.wing_area_m2
    disk_loading = AIRCRAFT.gross_weight_kg * G / disk_area_total
    power_loading = AIRCRAFT.gross_weight_kg * G / (AIRCRAFT.n_engines * AIRCRAFT.sea_level_power_per_engine_kW * 1000.0)
    return {
        "final_aircraft": {
            "MTOW_kg": AIRCRAFT.gross_weight_kg,
            "empty_mass_kg": AIRCRAFT.empty_weight_kg,
            "payload_kg": AIRCRAFT.max_payload_kg,
            "fuel_capacity_kg": AIRCRAFT.fuel_capacity_kg,
            "reserve_fuel_kg": mission_reserve(),
            "rotor_radius_m": ROTOR.R,
            "rotor_diameter_m": 2.0 * ROTOR.R,
            "number_of_rotors": AIRCRAFT.n_rotors,
            "blades_per_rotor": ROTOR.B,
            "root_cutout_m": ROTOR.r_root,
            "root_chord_m": ROTOR.chord_root,
            "taper_ratio": ROTOR.taper_ratio,
            "twist_root_to_tip_deg": [ROTOR.twist_root_deg, ROTOR.twist_tip_deg],
            "rpm_hover": ROTOR.rpm_hover,
            "rpm_cruise": ROTOR.rpm_cruise,
            "wing_area_m2": AIRCRAFT.wing_area_m2,
            "wing_span_m": AIRCRAFT.wing_span_m,
            "wing_mean_chord_m": AIRCRAFT.wing_mean_chord_m,
            "wing_AR": AIRCRAFT.wing_span_m**2 / AIRCRAFT.wing_area_m2,
            "horizontal_tail_area_m2": AIRCRAFT.htail_area_m2,
            "vertical_tail_area_m2": AIRCRAFT.vtail_area_m2,
            "engine_count": AIRCRAFT.n_engines,
            "power_per_engine_kW": AIRCRAFT.sea_level_power_per_engine_kW,
            "drivetrain_efficiency": AIRCRAFT.drivetrain_efficiency,
            "SFC_kg_per_kWh": AIRCRAFT.sfc_kg_per_kWh,
            "wing_loading_N_m2": wing_loading,
            "disk_loading_N_m2": disk_loading,
            "installed_power_loading_N_per_kW": power_loading * 1000.0,
            "CG_body_m": [AIRCRAFT.cg_x_m, AIRCRAFT.cg_y_m, AIRCRAFT.cg_z_m],
            "rotor_hub_body_m": [AIRCRAFT.rotor_hub_x_m, AIRCRAFT.rotor_half_span_m, AIRCRAFT.rotor_hub_z_m],
            "nacelle_angle_range_deg": [AIRCRAFT.nacelle_min_deg, AIRCRAFT.nacelle_max_deg],
            "nacelle_rate_limit_deg_s": AIRCRAFT.nacelle_rate_deg_s,
        },
        "hover": hover,
        "airplane_mode_cruise": cruise,
        "mission_settings": M3_SETTINGS,
        "mission": mission,
    }


def write_assessment_tables(hover: dict[str, float], cruise: dict[str, float], mission: dict[str, Any]) -> None:
    """Create reproducible M3 requirement/comparison tables from run results."""
    ref_path = INPUT / "reference_aircraft_v22.json"
    reference = json.loads(ref_path.read_text(encoding="utf-8"))
    our_disk_loading = AIRCRAFT.gross_weight_kg * G / (AIRCRAFT.n_rotors * math.pi * ROTOR.R**2)
    our_power_loading_kw_per_t = AIRCRAFT.n_engines * AIRCRAFT.sea_level_power_per_engine_kW / (AIRCRAFT.gross_weight_kg / 1000.0)
    our_payload_fraction = AIRCRAFT.max_payload_kg / AIRCRAFT.gross_weight_kg
    v22_disk_area = reference["rotor_count"] * math.pi * (reference["rotor_diameter_m"] / 2.0) ** 2
    v22_disk_loading = reference["max_vertical_takeoff_gross_mass_kg"] * G / v22_disk_area
    v22_total_power_kw = reference["engine_count"] * reference["power_per_engine_kW"]
    v22_power_loading_kw_per_t = v22_total_power_kw / (reference["max_vertical_takeoff_gross_mass_kg"] / 1000.0)
    v22_payload_fraction = reference["single_cargo_hook_payload_kg"] / reference["max_vertical_takeoff_gross_mass_kg"]
    comparison_rows = [
        ("MTOW basis", AIRCRAFT.gross_weight_kg, reference["max_vertical_takeoff_gross_mass_kg"], "kg", "Project MTOW vs V-22 manufacturer vertical-takeoff max gross mass"),
        ("Rotor disk loading", our_disk_loading, v22_disk_loading, "N/m^2", "Total weight divided by total rotor disk area"),
        ("Installed power per gross mass", our_power_loading_kw_per_t, v22_power_loading_kw_per_t, "kW/t", "Installed engine power divided by gross mass"),
        ("Payload fraction", our_payload_fraction * 100.0, v22_payload_fraction * 100.0, "%", "Project internal payload / MTOW vs V-22 single cargo-hook load / vertical-takeoff gross mass; not identical payload definitions"),
        ("Demonstrated / published cruise speed", cruise["airspeed_kt"], reference["max_cruise_speed_kt"], "kt", "Project model trimmed operating point vs V-22 published maximum cruise speed"),
    ]
    with (OUTPUT / "m3_design_comparison.csv").open("w", newline="", encoding="utf-8") as f:
        w=csv.writer(f); w.writerow(["metric","project_aircraft","bell_boeing_v22","units","definition_and_caveat"]); w.writerows(comparison_rows)

    requirements = [
        ("MTOW", "3000 kg design gross weight", f"{AIRCRAFT.gross_weight_kg:.1f} kg", "Achieved" if math.isclose(AIRCRAFT.gross_weight_kg,3000.0,abs_tol=1e-6) else "Review", "Final aircraft configuration input"),
        ("Payload", "550 kg", f"{AIRCRAFT.max_payload_kg:.1f} kg", "Achieved" if AIRCRAFT.max_payload_kg >= 550.0 else "Not achieved", "Mass budget; payload pickup/drop not separately modeled"),
        ("Sea-level OGE hover", "Hover at 3000 kg MTOW", f"{hover['total_shaft_power_required_kW']:.1f} kW required / {hover['power_available_kW']:.1f} kW available", "Achieved" if hover["power_margin_kW"] >= 0 else "Not achieved", "M1 axial BEMT; sea-level ISA; equal thrust sharing"),
        ("Maximum hover mass", ">= 3000 kg at sea level", "3205 kg per M1 analysis", "Achieved", "M1 reported maximum hover gross weight; do not infer altitude capability from this"),
        ("Cruise speed", f"{AIRCRAFT.design_cruise_speed_ms:.0f} m/s target", f"{cruise['airspeed_ms']:.1f} m/s trimmed", "Not achieved" if cruise["airspeed_ms"] < AIRCRAFT.design_cruise_speed_ms else "Achieved", "Trimmed M2 aircraft model point, 500 m ISA"),
        ("Design range", f">= {AIRCRAFT.design_range_km:.0f} km target", f"{mission['cruise_leg_distance_km']:.1f} km demonstrated cruise leg", "Not demonstrated", "The M3 mission is a representative 100 km cruise leg, not a maximum-range evaluation"),
        ("Service ceiling", f"{AIRCRAFT.service_ceiling_m:.0f} m target", "820 m M1 OGE hover ceiling at MTOW", "Not achieved in hover", "M1 hover-ceiling result; airplane-mode service ceiling not evaluated here"),
        ("Rotor stall screen", f"<= {ROTOR.stall_span_fraction_limit*100:.1f}% hard limit; {ROTOR.stall_span_fraction_warning*100:.1f}% warning", f"{mission['maximum_stalled_span_pct']:.2f}% maximum stalled span", "Within hard limit; warning exceeded" if mission["stall_warning_threshold_exceeded"] else "Within warning threshold", "M2 hard screen is 25%; the earlier 5% span criterion is retained as a warning"),
        ("Fuel reserve", f">= {mission['fuel_reserve_kg']:.1f} kg remaining", f"{mission['fuel_final_kg']:.1f} kg remaining", "Achieved" if mission["fuel_final_kg"] >= mission["fuel_reserve_kg"] else "Not achieved", "End-to-end mission fuel check"),
        ("Conversion mission", "Outbound + cruise + inbound + landing", "All configured segments completed", "Achieved in model" if mission["all_steps_feasible"] else "Not achieved", "Scheduled M2 Mission Planner v2 simulation; not a 6-DOF closed-loop flight test"),
    ]
    with (OUTPUT / "m3_requirement_compliance.csv").open("w", newline="", encoding="utf-8") as f:
        w=csv.writer(f); w.writerow(["requirement","target","final_result","status","basis_or_caveat"]); w.writerows(requirements)

    (OUTPUT / "m3_reference_comparison_notes.md").write_text(
        "# Published-aircraft comparison notes\n\n"
        "Reference aircraft: Bell Boeing V-22 Osprey. Values are read from `inputs/reference_aircraft_v22.json`. "
        "Rotor disk loading, installed power per gross mass, and speed are useful scale indicators, not proof of equivalent mission capability. "
        "Payload fraction is only indicative because the V-22 number is the single external cargo-hook load, whereas the project aircraft number is an internal payload allowance. "
        "Wing loading is omitted because a consistent wing reference area was not available in the selected manufacturer specifications.\n\n"
        f"Project rotor disk loading: {our_disk_loading:.1f} N/m²; V-22: {v22_disk_loading:.1f} N/m².\n"
        f"Project installed power: {our_power_loading_kw_per_t:.1f} kW/t; V-22: {v22_power_loading_kw_per_t:.1f} kW/t.\n"
        f"Project demonstrated cruise: {cruise['airspeed_kt']:.1f} kt; V-22 published maximum cruise: {reference['max_cruise_speed_kt']:.1f} kt.\n",
        encoding="utf-8"
    )


def write_markdown_summary(perf: dict[str, Any], mission_history: list[dict[str, Any]]) -> None:
    h = perf["hover"]; c = perf["airplane_mode_cruise"]; m = perf["mission"]
    lines = [
        "# Milestone 3 Final Performance and Mission Summary",
        "",
        "## Frozen configuration",
        f"MTOW {AIRCRAFT.gross_weight_kg:.0f} kg = {AIRCRAFT.empty_weight_kg:.0f} kg empty + {AIRCRAFT.max_payload_kg:.0f} kg payload + {AIRCRAFT.fuel_capacity_kg:.0f} kg fuel.",
        f"Twin rotors: R={ROTOR.R:.2f} m, B={ROTOR.B}, chord root={ROTOR.chord_root:.2f} m, taper={ROTOR.taper_ratio:.2f}, twist {ROTOR.twist_root_deg:.1f} to {ROTOR.twist_tip_deg:.1f} deg.",
        f"Wing: S={AIRCRAFT.wing_area_m2:.1f} m2, span={AIRCRAFT.wing_span_m:.1f} m, AR={AIRCRAFT.wing_span_m**2/AIRCRAFT.wing_area_m2:.2f}.",
        "",
        "## Hover (M1 axial BEMT, MTOW, sea level ISA)",
        f"Collective {h['collective_deg']:.2f} deg at {h['rpm']:.0f} RPM; thrust per rotor {h['thrust_per_rotor_N']:.0f} N; per-rotor aerodynamic power {h['power_per_rotor_aero_kW']:.1f} kW.",
        f"Total shaft power {h['total_shaft_power_required_kW']:.1f} kW vs {h['power_available_kW']:.1f} kW available; margin {h['power_margin_kW']:.1f} kW; FM={h['figure_of_merit']:.3f}.",
        "M1 reference: maximum hover gross weight 3,205 kg at sea level; OGE hover ceiling at MTOW 820 m.",
        "",
        f"## Airplane-mode cruise (re-trimmed, M2 model, {CRUISE_ALTITUDE_M:.0f} m ISA)",
        f"V={c['airspeed_ms']:.1f} m/s ({c['airspeed_kt']:.1f} kt), RPM={c['rpm']:.0f}, collective={c['collective_deg']:.2f} deg, pitch={c['pitch_deg']:.2f} deg.",
        f"Power required {c['power_required_kW']:.1f} kW vs {c['power_available_kW']:.1f} kW available; margin {c['power_margin_kW']:.1f} kW ({c['power_margin_pct_of_available']:.1f}%).",
        f"Estimated aircraft L/D={c['aircraft_L_over_D_estimate']:.2f}; propulsive efficiency estimate={c['propulsive_efficiency_estimate']:.2f}; trim max scaled residual={c['max_scaled_trim_residual']:.2e}.",
        "",
        "## End-to-end mission",
        f"Success: {m['success']}; time {m['mission_time_min']:.2f} min; cumulative path distance {m['total_distance_km']:.2f} km ({CRUISE_DISTANCE_M/1000:.1f} km level cruise leg).",
        f"Fuel {m['fuel_initial_kg']:.1f} -> {m['fuel_final_kg']:.1f} kg; burned {m['fuel_burn_kg']:.1f} kg; reserve {m['fuel_reserve_kg']:.1f} kg; landing gross mass {m['landing_mass_kg']:.1f} kg.",
        f"Peak power {m['max_power_required_kW']:.1f} kW; minimum power margin {m['minimum_power_margin_pct']:.2f}%.",
        f"Maximum predicted stalled span {m['maximum_stalled_span_pct']:.2f}% (M2 warning threshold {m['stall_warning_threshold_pct']:.1f}%, hard rejection threshold {m['stall_hard_limit_pct']:.1f}%); minimum margin to hard limit {m['minimum_stall_margin_to_hard_limit_percentage_points']:.2f} percentage points; minimum tip-Mach margin {m['minimum_tip_mach_margin']:.4f}.",
        f"Limiting point: {m['limiting_power_point']['segment']} at t={m['limiting_power_point']['time_s']/60:.2f} min, V={m['limiting_power_point']['airspeed_ms']:.1f} m/s, gamma={m['limiting_power_point']['nacelle_angle_deg']:.1f} deg.",
        "",
        "## Interpretation and validity",
        "Mission Planner v2 is a scheduled, low-order state/mass/fuel feasibility simulation. It is not a 6-DOF flight-dynamics or closed-loop pilot-control simulation. Conversion waypoints are reused from M2; the airplane-mode cruise point is explicitly trimmed and enforced.",
        "The primary M3 mission uses the M2 static Glauert/Drees inflow model for direct comparability. The optional three-state Pitt-Peters extension is retained as a separate, non-primary analysis and is not used for the graded M3 mission.",
        "",
    ]
    (OUTPUT / "m3_final_summary.md").write_text("\n".join(lines), encoding="utf-8")
    (OUTPUT / "m3_performance_and_mission.json").write_text(json.dumps(perf, indent=2), encoding="utf-8")


def main() -> int:
    print("[1/5] Solving M1 hover point...")
    hover = hover_performance()
    print(json.dumps(hover, indent=2))

    print("[2/5] Solving airplane-mode cruise trim on mission grid...")
    cruise, trim_result = solve_cruise_trim()
    print(json.dumps(cruise, indent=2))

    print("[3/5] Sizing a mass-aware cruise trim schedule...")
    planner = MissionPlannerV2(
        radial_stations=MISSION_GRID_RADIAL,
        n_azimuth=MISSION_GRID_AZIMUTH,
        inflow_model=INFLOW_MODEL,
        include_diagnostics=True,
    )
    # Run the pre-cruise mission once to obtain the actual fuel-reduced mass at
    # the start of cruise. This avoids assuming the cruise begins at MTOW.
    base_mission = build_final_mission(cruise)
    cruise_index = next(i for i, seg in enumerate(base_mission["segments"]) if seg["name"].startswith("airplane_mode_cruise_part"))
    prefix_mission = dict(base_mission)
    prefix_mission["segments"] = base_mission["segments"][:cruise_index]
    prefix_result = planner.run(prefix_mission, dt=MISSION_DT_S)
    if not prefix_result["success"]:
        raise RuntimeError(f"pre-cruise mission prefix failed: {prefix_result['failure']}")
    mass_at_cruise = float(prefix_result["final_gross_weight_kg"])

    cruise_part_trims = []
    previous_x = [cruise[k] for k in ("pitch_deg", "collective_deg", "theta_1c_lateral_deg", "theta_1s_longitudinal_deg", "elevator_deg", "rudder_deg", "aileron_deg")]
    mass_trim_iterations = max(1, int(CRUISE_SETTINGS.get("mass_trim_iterations", 2)))
    for part_i, duration in enumerate(CRUISE_SEGMENT_DURATIONS_S, 1):
        # Solve controls at a representative mass within the segment, iterating
        # fuel burn and trim until the configured number of updates is reached.
        trim_i = None
        solved_i = None
        p_guess = cruise["power_required_kW"]
        for _ in range(mass_trim_iterations):
            burn_guess = AIRCRAFT.sfc_kg_per_kWh * p_guess * duration / 3600.0
            trim_mid_mass = mass_at_cruise - 0.5 * burn_guess
            trim_i, solved_i = solve_cruise_trim(gross_mass_kg=trim_mid_mass, x0=previous_x if solved_i is None else solved_i["x"])
            p_guess = trim_i["power_required_kW"]
        cruise_part_trims.append(trim_i)
        previous_x = [trim_i[k] for k in ("pitch_deg", "collective_deg", "theta_1c_lateral_deg", "theta_1s_longitudinal_deg", "elevator_deg", "rudder_deg", "aileron_deg")]
        mass_at_cruise -= AIRCRAFT.sfc_kg_per_kWh * trim_i["power_required_kW"] * duration / 3600.0
        print(f"  cruise part {part_i}: reference mass {trim_i['gross_mass_kg']:.1f} kg, P={trim_i['power_required_kW']:.1f} kW, residual={trim_i['max_scaled_trim_residual']:.2e}")

    print("[4/5] Building and running the M3 mission (static M2 inflow)...")
    mission = build_final_mission(cruise, cruise_part_trims)
    write_json(INPUT / "mission_final.json", mission)
    result = planner.run(mission, dt=MISSION_DT_S)
    if not result["history"]:
        raise RuntimeError("mission returned empty history")
    if not result["success"]:
        print("MISSION FAILED", result["failure"])
        raise RuntimeError(f"M3 mission not feasible: {result['failure']}")
    history = augment_history_with_distance(result["history"], mission)
    write_history(OUTPUT / "m3_mission_history.csv", history)
    mission_summary = summarize_mission(history, mission, result)
    (OUTPUT / "m3_mission_segment_summary.json").write_text(json.dumps(mission_summary, indent=2), encoding="utf-8")
    (OUTPUT / "m3_mission_segment_summary.csv").write_text(
        "\n".join([",".join(mission_summary["segment_summary"][0].keys())] + [
            ",".join(str(row[k]) for k in mission_summary["segment_summary"][0].keys())
            for row in mission_summary["segment_summary"]
        ]) + "\n", encoding="utf-8")
    if not result["success"]:
        print("MISSION FAILED", result["failure"])
        raise RuntimeError(f"M3 mission not feasible: {result['failure']}")
    if not mission_summary["all_steps_feasible"]:
        raise RuntimeError("Mission contains one or more infeasible steps despite success flag")

    print("[5/5] Generating performance summary and mission plots...")
    perf = performance_summary(hover, cruise, mission_summary)
    write_assessment_tables(hover, cruise, mission_summary)
    write_markdown_summary(perf, history)
    plot_mission(history, mission_summary)
    plot_design_summaries(hover, cruise, mission_summary, history)
    print(json.dumps(mission_summary, indent=2))
    print("M3 final analysis complete.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
