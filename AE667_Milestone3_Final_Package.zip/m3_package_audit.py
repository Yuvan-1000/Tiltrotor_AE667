"""Audit the final AE 667 Milestone 3 code package and generated evidence.

Checks source/input/output completeness, end-to-end mission feasibility,
minimum reserve, and numerical consistency between the mission history and
its summary JSON. Run from any working directory with:
    python /path/to/m3_package_audit.py
"""
from __future__ import annotations

import csv
import json
import math
import struct
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REQUIRED_FILES = [
    "README.md", "REFERENCES.md", "ACKNOWLEDGEMENT.md", "FINAL_PACKAGE_CHECKLIST.md",
    "requirements.txt", "requirements-dev.txt", "environment.yml",
    "aircraft_config.py", "aircraft_model.py", "bemt_solver.py", "edgewise_bemt.py",
    "trim_solver.py", "mission_planner_v2.py", "run_m3_final.py",
    "package_audit.py", "m3_package_audit.py",
    "inputs/aircraft_config.json", "inputs/m3_mission_settings.json",
    "inputs/example_transition_outbound.json", "inputs/example_transition_inbound.json",
    "inputs/reference_aircraft_v22.json", "inputs/mission_final.json",
    "outputs/m3_final_summary.md", "outputs/m3_performance_and_mission.json",
    "outputs/m3_mission_history.csv", "outputs/m3_mission_segment_summary.csv",
    "outputs/m3_mission_segment_summary.json", "outputs/m3_requirement_compliance.csv",
    "outputs/m3_design_comparison.csv", "outputs/m3_reference_comparison_notes.md",
    "outputs/task3_4_discretization_sensitivity.csv",
]
REQUIRED_FIGURES = [
    "m3_final_aircraft_schematic.png", "m3_hover_cruise_power.png",
    "m3_efficiency_metrics.png", "m3_conversion_map_path.png",
    "m3_mission_trajectory.png", "m3_mission_fuel_mass.png",
    "m3_mission_configuration.png", "m3_mission_power.png", "m3_mission_margins.png",
]
REQUIRED_HISTORY_COLUMNS = {
    "segment", "time_s", "altitude_m", "airspeed_ms", "ground_speed_ms",
    "cumulative_distance_km", "gross_weight_kg", "fuel_remaining_kg",
    "nacelle_angle_deg", "rpm", "P_required_kW", "P_available_kW",
    "stall_margin_pct", "tip_mach_margin", "stalled_span_pct",
    "stall_margin_to_warning_pp", "fuel_before_kg", "fuel_burn_kg", "feasible",
}
REQUIRED_SEGMENT_TOKENS = [
    "pre_takeoff_hover", "vertical_takeoff_and_climb", "outbound_conversion_",
    "airplane_mode_cruise_part", "inbound_conversion_",
    "vertical_descent_and_landing_approach", "landing_hover_and_touchdown",
]


def _close(a: float, b: float, *, rel: float = 2e-5, abs_: float = 2e-4) -> bool:
    return math.isclose(float(a), float(b), rel_tol=rel, abs_tol=abs_)


def _png_is_valid(path: Path) -> bool:
    try:
        with path.open("rb") as f:
            header = f.read(24)
        if len(header) != 24 or header[:8] != b"\x89PNG\r\n\x1a\n":
            return False
        width, height = struct.unpack(">II", header[16:24])
        return width >= 400 and height >= 250
    except (OSError, struct.error):
        return False


def main() -> int:
    missing = [f for f in REQUIRED_FILES if not (ROOT / f).is_file()]
    missing += [f"figures/{f}" for f in REQUIRED_FIGURES
                if not _png_is_valid(ROOT / "figures" / f)]
    missing += ["tests/ directory" for _ in [0] if not (ROOT / "tests").is_dir()]
    if missing:
        print("M3 PACKAGE AUDIT FAILED — missing/invalid files:")
        print("\n".join(f" - {x}" for x in missing))
        return 1

    try:
        mission = json.loads((ROOT / "inputs/mission_final.json").read_text(encoding="utf-8"))
        summary = json.loads((ROOT / "outputs/m3_mission_segment_summary.json").read_text(encoding="utf-8"))
        perf = json.loads((ROOT / "outputs/m3_performance_and_mission.json").read_text(encoding="utf-8"))
        settings = json.loads((ROOT / "inputs/m3_mission_settings.json").read_text(encoding="utf-8"))
        aircraft = json.loads((ROOT / "inputs/aircraft_config.json").read_text(encoding="utf-8"))
        rows = list(csv.DictReader((ROOT / "outputs/m3_mission_history.csv").open(encoding="utf-8", newline="")))
        segments = list(csv.DictReader((ROOT / "outputs/m3_mission_segment_summary.csv").open(encoding="utf-8", newline="")))
    except Exception as exc:
        print(f"M3 PACKAGE AUDIT FAILED — could not read generated evidence: {exc}")
        return 1

    problems: list[str] = []
    if not summary.get("success") or not summary.get("all_steps_feasible"):
        problems.append("mission summary does not report success / all-feasible")
    if perf.get("mission", {}).get("success") is not True:
        problems.append("performance summary JSON does not contain a successful mission")
    if not rows or not all(r.get("feasible") == "True" for r in rows):
        problems.append("time-history is empty or contains infeasible samples")
    if not segments or len(segments) != len(mission.get("segments", [])):
        problems.append("CSV segment summary does not match mission segment count")
    if rows and not REQUIRED_HISTORY_COLUMNS.issubset(rows[0].keys()):
        problems.append("mission history is missing one or more required M3 output columns")

    names = [str(s.get("name", "")) for s in mission.get("segments", [])]
    for token in REQUIRED_SEGMENT_TOKENS:
        if not any(token in n for n in names):
            problems.append(f"mission definition is missing segment token: {token}")
    if mission.get("inflow_model") != "static M2 baseline":
        problems.append("primary M3 mission is not marked as static M2 baseline")

    reserve = float(summary.get("fuel_reserve_kg", 0.0))
    if float(summary.get("fuel_final_kg", 0.0)) < reserve:
        problems.append("mission ends below reserve fuel")
    if float(summary.get("minimum_power_margin_pct", -1.0)) < 0.0:
        problems.append("mission contains a negative reported power margin")
    if float(summary.get("minimum_tip_mach_margin", -1.0)) < 0.0:
        problems.append("mission exceeds the advancing-tip Mach limit")
    if float(summary.get("minimum_stall_margin_to_hard_limit_percentage_points", -1.0)) < 0.0:
        problems.append("mission exceeds the M2 hard stalled-span threshold")
    if not rows or not all("stalled_span_pct" in r and "stall_margin_to_warning_pp" in r for r in rows):
        problems.append("M3 diagnostic stall columns are absent from mission history")

    # Mission definition must reproduce the requested level-cruise distance.
    cruise = settings.get("cruise", {})
    sim = settings.get("simulation", {})
    expected_duration = float(cruise.get("distance_m", 0.0)) / float(cruise.get("airspeed_ms", 1.0))
    configured_duration = sum(float(x) for x in cruise.get("segment_durations_s", [expected_duration]))
    if abs(configured_duration - expected_duration) > float(sim.get("time_step_s", 1.0)) + 1e-9:
        problems.append("cruise segment durations do not match configured distance / speed")
    if int(sim.get("radial_stations", 0)) < 80:
        problems.append("M3 mission radial grid is below the documented M2 production radial resolution")
    if int(sim.get("azimuth_stations", 0)) < 12:
        problems.append("M3 mission azimuth grid is below the lowest documented sensitivity point")

    # Configuration mass closure.
    ac = aircraft.get("aircraft", {})
    mass_sum = (float(ac.get("empty_weight_kg", 0.0))
                + float(ac.get("max_payload_kg", 0.0))
                + float(ac.get("fuel_capacity_kg", 0.0)))
    if not _close(mass_sum, float(ac.get("gross_weight_kg", -1.0)), rel=0.0, abs_=1e-7):
        problems.append("final aircraft mass budget does not close at MTOW")

    # Independently reconcile key mission metrics from the time history.
    if rows:
        try:
            max_power = max(float(r["P_required_kW"]) for r in rows)
            min_power_margin = min(float(r["power_margin_pct"]) for r in rows)
            max_stall = max(float(r["stalled_span_pct"]) for r in rows)
            last = rows[-1]
            last_distance = float(last["cumulative_distance_km"])
            last_fuel = float(last["fuel_remaining_kg"])
            last_mass = float(last["gross_weight_kg"])
            mass_error = max(abs(float(r["gross_weight_kg"])
                                  - (float(ac["empty_weight_kg"])
                                     + float(ac["max_payload_kg"])
                                     + float(r["fuel_before_kg"]))) for r in rows)
            if not _close(max_power, summary["max_power_required_kW"]):
                problems.append("peak power in summary does not match mission history")
            if not _close(min_power_margin, summary["minimum_power_margin_pct"]):
                problems.append("minimum power margin in summary does not match mission history")
            if not _close(max_stall, summary["maximum_stalled_span_pct"]):
                problems.append("maximum stalled span in summary does not match mission history")
            if not _close(last_distance, summary["total_distance_km"]):
                problems.append("final distance in summary does not match mission history")
            if not _close(last_fuel, summary["fuel_final_kg"]):
                problems.append("final fuel in summary does not match mission history")
            if not _close(last_mass, summary["landing_mass_kg"]):
                problems.append("landing mass in summary does not match mission history")
            if mass_error > 1e-3:
                problems.append(f"gross mass / empty+payload+fuel closure error is {mass_error:.4g} kg")
            if not _close(float(last["time_s"]), summary["mission_time_s"], rel=0.0, abs_=1e-9):
                problems.append("mission time summary does not match the final time-history sample")
        except (KeyError, TypeError, ValueError) as exc:
            problems.append(f"could not reconcile mission history values: {exc}")

    if problems:
        print("M3 PACKAGE AUDIT FAILED:")
        print("\n".join(f" - {x}" for x in problems))
        return 1

    print("M3 PACKAGE AUDIT PASSED")
    print(f"- Mission samples: {len(rows)}")
    print(f"- Mission segments: {len(names)}")
    print(f"- Mission grid: {sim['radial_stations']} radial × {sim['azimuth_stations']} azimuth")
    print(f"- Duration: {summary['mission_time_min']:.2f} min")
    print(f"- Fuel remaining: {summary['fuel_final_kg']:.1f} kg (reserve {reserve:.1f} kg)")
    print(f"- Minimum power margin: {summary['minimum_power_margin_pct']:.2f}%")
    print(f"- Maximum stalled span: {summary['maximum_stalled_span_pct']:.2f}% (5% warning / 25% hard screen)")
    print("- Mission-history and summary metrics reconcile")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
