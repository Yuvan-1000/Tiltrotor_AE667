# Milestone 2 Task Map

| M2 task | Required work | Main implementation | Main evidence |
|---|---|---|---|
| 1 | Coordinate systems and transformations | `task1_coordinate_systems.py`, `edgewise_bemt.py`, `aircraft_config.py` | coordinate figure + conventions/assumptions |
| 2 | Azimuth-resolved rotor model | `edgewise_bemt.py` + `task2_updated_algorithms.py` | edgewise flow demonstration + 2.1/2.2/2.3 flow diagrams |
| 3 | Forward/edgewise-flow physics | `edgewise_bemt.py` + `task3_forward_flight_physics.py` | M1 limiting recovery, loading contour, reverse flow, Mach/stall, sensitivity |
| 4 | Rotor forces and moments | `edgewise_bemt.py` + `aircraft_model.py` + `task4_rotor_forces_moments.py` | rotor/body/CG load tables and torque-cancellation check |
| 5 | Control-response study | `task5_control_response.py` | collective/longitudinal cyclic/lateral cyclic at helicopter-like + intermediate conditions |
| 6 | Aircraft aerodynamic model for transition | `aircraft_model.py` + `task6_aircraft_aerodynamic_model.py` | schematic, design tables, wing/airframe model |
| 7 | Trim solver | `trim_solver.py` + `task7_trimmed_flight.py` | 3×3 trim matrix, full six-load result table, failed case |
| 8 | Conversion-state analysis | `task8_conversion_corridor.py` | resolved speed–nacelle-angle feasibility map + active-constraint map |
| 9 | Mission Planner v2 | `mission_planner_v2.py` + `task9_mission_planner_v2.py` | outbound + inbound complete time histories |
| 10 | Design refinement | `task10_design_refinement.py` | M1/M2 comparison, design-change table, range sanity, M3 plan |

The report numbering in the provided M2 PDF is also reflected in filenames inside `outputs/` so the same code package can reproduce the graded report sections without using separate project tracks.


## Dependency chain

Task 1 writes the common aircraft configuration input. Task 2 documents the three algorithm interfaces. Task 3 verifies the edgewise rotor against the unchanged M1 axial backend. Task 4 validates the rotor/body/CG load transformation used by Tasks 5–9. Task 5 exercises pilot inputs. Task 6 defines the airframe model consumed by Task 7. Task 7 creates the required 3×3 trim matrix. Task 8 reuses that matrix as the seed for the resolved corridor. Task 9 uses the same aircraft model/configuration for outbound and inbound conversion missions. Task 10 consumes M1/M2 results and provides the refinement, integrated assessment and M3 plan.
