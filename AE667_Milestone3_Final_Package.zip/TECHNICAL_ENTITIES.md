# Milestone 2 Technical Entities / Test Cases

These are the numerical test cases used to verify that the workflow is producing physically interpretable outputs.

## Task 1–3 representative edgewise case

- RPM = 750
- Collective = 14°
- Nacelle angle = 90°
- Airspeed represented as V_edge = 35 m/s, V_axial = 0 m/s
- Altitude = 0 m
- ISA temperature offset = 0 K
- Cyclic = 0°
- Radial stations = 80
- Azimuth stations = 96

This is used for the azimuthal contour, reverse-flow/stall/Mach diagnostics and sensitivity tests.

## Task 5 control-response conditions

1. Helicopter-like: γ=90°, V=20 m/s, 750 RPM, 500 m, ISA, θ0=14°.
2. Intermediate conversion: γ=45°, V=10 m/s, 750 RPM, 500 m, ISA, θ0=14°.

Course convention: θ1c is lateral cyclic; θ1s is longitudinal cyclic.

## Task 7 trim matrix

- Nacelle angles: 90°, 45°, 0°.
- Airspeeds: 20, 30, 40 m/s.
- Altitude = 500 m.
- Gross mass = 3000 kg.
- ISA offset = 0 K.
- RPM policy = 750 RPM for γ≥60°, 650 RPM for γ<60°.

## Task 8 corridor map

- Nacelle angle grid: 0° to 90° in 5° increments.
- Airspeed grid: 10 to 45 m/s in 2 m/s increments.
- Altitude = 500 m.
- Gross mass = 3000 kg.
- Controls are seeded from the Task 7 3×3 trim table and checked directly with the aircraft model.

## Task 9 missions

Both missions begin/end with the same 3000 kg aircraft configuration, use 500 kg initial fuel, 10% reserve policy, zero wind, 1 s timestep and the same rotor/wing/airframe model.

Outbound: takeoff/initial climb → nacelle conversion 90°→0° → airplane hold.
Inbound: airplane hold → nacelle conversion 0°→90° → hover descent.
