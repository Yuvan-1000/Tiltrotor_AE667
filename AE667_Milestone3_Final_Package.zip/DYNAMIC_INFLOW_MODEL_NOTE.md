# Dynamic-inflow implementation and verification note

## Formulation in this package

The extension uses a three-state Pitt–Peters-style inflow model with uniform and first azimuthal harmonic states:

`lambda_i(r, psi) = lambda_0 + (r/R) * (lambda_c*cos(psi) + lambda_s*sin(psi))`.

The time evolution is expressed in rotor azimuth, `psi = Omega*t`, with the state derivative driven by rotor loading coefficients and a model influence matrix. `dynamic_inflow.py` contains the state equations, integration methods, parameter validation and analytical uniform-hover solution. `dynamic_inflow_rotor.py` couples the states to the existing edgewise BEMT solver. The M2 rotor and mission tool can select the original static inflow, quasi-steady Pitt–Peters, or time-integrated Pitt–Peters mode.

The canonical apparent-mass constants used as a source-backed default are `M0 = 128/(75*pi)` and `M1 = 64/(45*pi)`, cross-checked against the Pitt–Peters formulation documented by BladeAD. The implementation applies a transformed sign convention for the first-harmonic states to match the M2 rotor/azimuth/moment convention; signs should not be copied between implementations without comparing those definitions. This is a convention alignment, not a fitted validation parameter.

## Test and analytical verification evidence

Run:

```bash
pytest -q
python package_audit.py
python validate_dynamic_inflow.py
```

The test suite covers the limiting/analytical hover behaviour, timestep integration, sign conventions, selected forward-flight limits, baseline M1 regression, and M2/dynamic-inflow integration. The analytical verification script compares the integrated uniform hover state with the exact solution of the model's nonlinear hover ODE and generates `outputs/dynamic_inflow_analytic_verification.csv`, JSON/Markdown summary and `figures/dynamic_inflow_hover_step.png`.

The previous local run passed all **34 tests** after the constants and test-path corrections. Re-run the commands above after unpacking the submitted archive; that is the verification result to report if the same clean run succeeds.

## Task 11 assessment

`task11_dynamic_inflow_assessment.py` compares:

- `static`: original M2 static-inflow baseline;
- `pitt_peters_qs`: Pitt–Peters state at instantaneous equilibrium;
- `pitt_peters`: states integrated dynamically.

The study includes (A) collective pitch transients and a speed/step-size sweep, (B) a longitudinal-cyclic step, and (C) outbound conversion missions at multiple nacelle rates. Assessment conditions are in `inputs/dynamic_inflow_assessment.json`; the outbound mission is in `inputs/example_transition_outbound.json`. The mission study uses the configured 10-radial by 8-azimuth integration grid and reports at the configured interval. The dynamic inflow ODE may substep internally to respect its integration stability limit.

Task 11 illustrates the expected qualitative mechanisms (transient lag and load/power differences) for the current low-order model. The predictions are numerical model outputs, not measured aircraft performance. Compression of the conversion time changes the mission schedule and should be treated as a controlled sensitivity study rather than an operational recommendation.

## What is and is not validated

The exact uniform-hover ODE comparison and grid/time-step checks provide analytical code verification. Regression checks show that the supplied baseline targets remain recoverable. These checks verify arithmetic, state evolution, and compatibility against known internal targets.

**Independent experimental validation of the complete dynamic-inflow implementation is not included as a completed result in this package.** The published studies in `REFERENCES.md` include suitable experimental/model comparisons, but the delivered files do not contain a directly comparable digitized experimental transient or inflow dataset with documented units and matching rotor/flight conditions. Do not describe the current implementation as experimentally validated until that comparison has been assembled and quantitatively evaluated.

## Assumptions and limitations

- Three-state model: only the uniform component and the first two azimuthal harmonics are retained.
- No free-wake geometry, higher inflow harmonics, individual-vortex dynamics, or blade-vortex interaction.
- Existing M2 airframe model remains low order and omits rotor-wake/wing interference; blade flapping and dynamic stall are not included.
- Airfoil polars are simplified and are not a complete Reynolds-/Mach-dependent experimental polar set.
- Predictions outside the model's validity range—including complex vortex-ring and windmill-brake states—need dedicated handling and validation.
- Numerical convergence and source checking do not eliminate model-form error. Interpret predicted transients and mission differences as engineering estimates within these limitations.

## Source links

- Pitt, D. M., & Peters, D. A. (1981), “Theoretical Prediction of Dynamic-Inflow Derivatives,” *Vertica*, 5(1), 21–34. https://mst.elsevierpure.com/en/publications/theoretical-prediction-of-dynamic-inflow-derivatives/
- Chen, R. T. N., & Hindson, W. S. (1986), NASA TM-88327, *Influence of Dynamic Inflow on the Helicopter Vertical Response*. https://ntrs.nasa.gov/citations/19870047579
- Chen, R. T. N. (1989), NASA TM-102219, *A Survey of Nonuniform Inflow Models for Rotorcraft Flight Dynamics and Control Applications*. https://ntrs.nasa.gov/citations/19900051466
- Hoad, D. R. (1990), NASA TP-2946, *Rotor Induced-Inflow-Ratio Measurements and CAMRAD Calculations*. https://ntrs.nasa.gov/citations/19900006566
- BladeAD, *Pitt-Peters Inflow Model*. https://bladead.readthedocs.io/en/latest/src/background/pitt_peters.html
