"""Reproducible analytical verification of the three-state dynamic-inflow solver.

Run from the package root:
    python validate_dynamic_inflow.py

This verifies the implementation against an exact analytical hover thrust-step
solution and writes a time-history CSV, convergence summary, and figure. It is
code verification against an analytical solution, not a substitute for wind-tunnel
or flight-data validation.
"""
from __future__ import annotations
import csv
import json
import math
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import dynamic_inflow as di

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "outputs"
DATA = ROOT / "data"
FIG = ROOT / "figures"
for p in (OUT, DATA, FIG):
    p.mkdir(parents=True, exist_ok=True)

RPM = 750.0
OMEGA = RPM * 2.0 * math.pi / 60.0
CT_INITIAL = 0.0030
CT_FINAL = 0.0045
T_END_S = 0.5
DT_S = 0.001
P = di.DynamicInflowParams()

# Source-backed coefficient assertion (BladeAD Pitt-Peters documentation,
# citing Pitt & Peters): the selected canonical values are not fitted here.
expected_m0 = 128.0 / (75.0 * math.pi)
expected_m1 = 64.0 / (45.0 * math.pi)
assert math.isclose(P.M0, expected_m0, rel_tol=0.0, abs_tol=1e-14)
assert math.isclose(P.M1, expected_m1, rel_tol=0.0, abs_tol=1e-14)

# Exact hover equilibrium before and after a positive thrust step.
lam_initial = math.sqrt(CT_INITIAL / 2.0)
lam_final = math.sqrt(CT_FINAL / 2.0)
times = np.arange(0.0, T_END_S + 0.5 * DT_S, DT_S)
lam = np.array([lam_initial, 0.0, 0.0])
rows = []
for i, t in enumerate(times):
    exact = float(di.hover_step_exact(np.array([t]), lam_initial, lam_final, OMEGA, P)[0])
    error = abs(lam[0] - exact)
    rows.append({
        "time_s": float(t),
        "CT_initial": CT_INITIAL,
        "CT_final": CT_FINAL,
        "RPM": RPM,
        "lambda0_numerical": float(lam[0]),
        "lambda0_exact": exact,
        "absolute_error": error,
        "relative_error_pct": 100.0 * error / max(abs(exact), 1e-15),
    })
    if i < len(times) - 1:
        lam = di.step(lam, np.array([CT_FINAL, 0.0, 0.0]), OMEGA, 0.0, 0.0,
                      DT_S, P, method="rk4")

csv_path = OUT / "dynamic_inflow_analytic_verification.csv"
with csv_path.open("w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    w.writeheader(); w.writerows(rows)

# Observed global error at several time steps against the exact solution.
convergence = []
for dt in (0.008, 0.004, 0.002, 0.001):
    n = int(round(T_END_S / dt))
    x = np.array([lam_initial, 0.0, 0.0])
    for _ in range(n):
        x = di.step(x, np.array([CT_FINAL, 0.0, 0.0]), OMEGA, 0.0, 0.0, dt, P, "rk4")
    exact_end = float(di.hover_step_exact(np.array([T_END_S]), lam_initial, lam_final, OMEGA, P)[0])
    convergence.append({"dt_s": dt, "steps": n, "lambda0_at_end": float(x[0]),
                        "exact_lambda0_at_end": exact_end,
                        "absolute_error": abs(float(x[0]) - exact_end)})
for j in range(1, len(convergence)):
    e0, e1 = convergence[j-1]["absolute_error"], convergence[j]["absolute_error"]
    convergence[j]["observed_order"] = (math.log(e0/e1, 2) if e0 > 0 and e1 > 0 else None)
convergence[0]["observed_order"] = None

max_abs = max(r["absolute_error"] for r in rows)
max_rel = max(r["relative_error_pct"] for r in rows)
summary = {
    "model": "Three-state Pitt-Peters dynamic inflow; uniform hover mode isolated",
    "benchmark_type": "exact analytical solution of hover equation M0*d(lambda0)/d(psi) + 2*lambda0^2 = CT",
    "independent_experimental_validation": False,
    "M0": P.M0,
    "M1": P.M1,
    "RPM": RPM,
    "CT_initial": CT_INITIAL,
    "CT_final": CT_FINAL,
    "dt_s": DT_S,
    "end_time_s": T_END_S,
    "max_abs_lambda0_error": max_abs,
    "max_relative_lambda0_error_pct": max_rel,
    "convergence": convergence,
}
(OUT / "dynamic_inflow_analytic_verification.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

md = [
    "# Dynamic-inflow analytical verification",
    "",
    "## Scope",
    "The uniform hover state is checked against the exact solution of the model's nonlinear hover ODE. This is an analytical code-verification benchmark, not experimental validation of Pitt–Peters against a physical rotor.",
    "",
    "## Case",
    f"- RPM: {RPM:.1f}",
    f"- Thrust coefficient step: {CT_INITIAL:.5f} → {CT_FINAL:.5f}",
    f"- Time step: {DT_S:.4f} s; duration: {T_END_S:.3f} s",
    f"- Published apparent-mass constants used: M0 = 128/(75π) = {P.M0:.9f}; M1 = 64/(45π) = {P.M1:.9f}",
    "",
    "## Result",
    f"- Maximum absolute error in λ₀ over the complete time history: {max_abs:.6e}",
    f"- Maximum relative error over the complete time history: {max_rel:.6e}%",
    "",
    "## Time-step convergence",
    "| dt (s) | Steps | Absolute end-state error | Observed order |",
    "|---:|---:|---:|---:|",
]
for c in convergence:
    order = "—" if c.get("observed_order") is None else f"{c['observed_order']:.3f}"
    md.append(f"| {c['dt_s']:.4f} | {c['steps']} | {c['absolute_error']:.6e} | {order} |")
md.extend([
    "",
    "## Interpretation and limitation",
    "The numerical solution should converge to the analytical trajectory and final momentum-theory value. This verifies integration of the stated hover-mode equation and its time-step behaviour. It does not, by itself, verify all forward-flight influence-matrix constants, moment normalisations, or physical prediction accuracy; published experimental validation remains a distinct step.",
])
(OUT / "dynamic_inflow_analytic_verification.md").write_text("\n".join(md) + "\n", encoding="utf-8")

fig, ax = plt.subplots(figsize=(7.2, 4.5))
ax.plot(times * 1000.0, [r["lambda0_exact"] for r in rows], label="Exact analytical solution", linewidth=2)
ax.plot(times * 1000.0, [r["lambda0_numerical"] for r in rows], "--", label="RK4 numerical solution", linewidth=1.5)
ax.axhline(lam_final, linestyle=":", linewidth=1.2, label="Final steady value")
ax.set_xlabel("Time after thrust step [ms]")
ax.set_ylabel("Uniform induced inflow ratio, λ₀ [-]")
ax.set_title("Pitt–Peters uniform hover state: analytical verification\n750 RPM; Cₜ 0.0030 → 0.0045")
ax.grid(True, alpha=0.3); ax.legend(); fig.tight_layout()
fig.savefig(FIG / "dynamic_inflow_hover_step.png", dpi=200); plt.close(fig)

print(f"PASS: constants M0={P.M0:.9f}, M1={P.M1:.9f}")
print(f"PASS: max |lambda0_numerical-lambda0_exact| = {max_abs:.6e}")
print(f"Wrote {csv_path.relative_to(ROOT)}")
print(f"Wrote outputs/dynamic_inflow_analytic_verification.md and figures/dynamic_inflow_hover_step.png")
