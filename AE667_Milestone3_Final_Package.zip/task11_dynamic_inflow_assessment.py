"""Task 11 - Dynamic-inflow rotorcraft assessment (Advanced Concept Modeling project).

Three inflow models are compared on the SAME rotor / aircraft:
  baseline   : original M2 static Glauert/Drees inflow                  (inflow_model='static')
  QS-PP      : quasi-steady Pitt-Peters (dx/dt = 0 at every instant)     (inflow_model='pitt_peters_qs')
  dynamic-PP : time-accurate Pitt-Peters                                 (inflow_model='pitt_peters')

dynamic-PP minus QS-PP isolates the effect of inflow DYNAMICS.
QS-PP minus baseline isolates the effect of the inflow MODEL (momentum-consistent mean + P-P harmonics).

Run:  python task11_dynamic_inflow_assessment.py [A] [B] [C]     (default: all parts)
  A  collective step: time history + step-size x speed sweep      (rotor level, ~1 min)
  B  longitudinal-cyclic step: pitch/roll moment lag and coupling (rotor level, ~20 s)
  C  outbound hover->airplane conversion at several nacelle rates (mission level, ~3 min)
Outputs: outputs/task11_*.csv|md, figures/task11_*.png
"""
from __future__ import annotations
import copy, csv, json, math, os, sys, warnings
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

warnings.simplefilter("ignore")
ROOT = os.path.dirname(os.path.abspath(__file__))
OUT, FIG, IN = (os.path.join(ROOT, d) for d in ("outputs", "figures", "inputs"))
for d in (OUT, FIG):
    os.makedirs(d, exist_ok=True)

from aircraft_config import AIRCRAFT, TILTROTOR_GEOM, TILTROTOR_AIRFOIL
from edgewise_bemt import EdgewiseBEMTSolver, EdgewiseFlightCondition as F
from dynamic_inflow_rotor import DynamicInflowRotor
from mission_planner_v2 import MissionPlannerV2

SOLVER = EdgewiseBEMTSolver(TILTROTOR_GEOM, TILTROTOR_AIRFOIL)
DYN = DynamicInflowRotor(SOLVER)
C = {"baseline": "tab:gray", "QS-PP": "tab:blue", "dynamic-PP": "tab:red"}
with open(os.path.join(IN, "dynamic_inflow_assessment.json"), encoding="utf-8") as _cfg_file:
    CFG = json.load(_cfg_file)
RC = CFG["rotor_condition"]
BASE_COL = float(RC["collective_baseline_deg"])
RPM = float(RC["rpm"])
ALTITUDE_M = float(RC["altitude_m"])


def flight(col, Ve, th1c=0.0, th1s=0.0, na=None):
    if na is None:
        na = int(RC["azimuth_stations_for_rotor_transients"])
    return F.from_rpm(RPM, col, th1c, th1s, V_edge=Ve, V_axial=0.0, n_azimuth=na, altitude=ALTITUDE_M)


def csv_write(name, rows):
    with open(os.path.join(OUT, name), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)


def march(f_new, lam0, t_end, dt):
    """Dynamic response after an abrupt change to f_new, starting from inflow state lam0."""
    lam, t, rec = lam0.copy(), 0.0, []
    for _ in range(int(round(t_end / dt)) + 1):
        r = DYN.loads(f_new, lam)
        rec.append(dict(t=t, T=r["T"], P=r["P"], stall=r["stalled_span_fraction"],
                        lam0=lam[0], lam_s=lam[1], lam_c=lam[2],
                        Mx=r["M_hub_rotor"][0], My=r["M_hub_rotor"][1]))
        lam = DYN.advance(f_new, lam, dt); t += dt
    return rec


def snapshot(r):
    return dict(T=r["T"], P=r["P"], stall=r["stalled_span_fraction"],
                Mx=r["M_hub_rotor"][0], My=r["M_hub_rotor"][1])


# ----------------------------------------------------------------------------- A
def part_A():
    print("[A] collective step ...")
    Ve = float(RC["edgewise_speed_for_steps_ms"])
    c1 = float(RC["collective_baseline_deg"])
    c2 = float(RC["collective_step_final_deg"])
    f1, f2 = flight(c1, Ve), flight(c2, Ve)
    lam1, r1 = DYN.equilibrium(f1)
    lam2, r2 = DYN.equilibrium(f2)
    b1, b2 = SOLVER.solve(f1), SOLVER.solve(f2)
    rec = march(f2, lam1, float(RC["step_duration_s"]), float(RC["step_dt_s"]))
    csv_write("task11_A1_collective_step_timehistory.csv", rec)
    t = np.array([r["t"] for r in rec])
    fig, ax = plt.subplots(2, 2, figsize=(10, 6.5))
    for a, key, lab, sc in zip(ax.flat, ("T", "P", "lam0", "stall"),
                               ("Rotor thrust [kN]", "Rotor shaft power [kW]", r"Uniform inflow $\lambda_0$ [-]",
                                "Stalled span fraction [-]"), (1e-3, 1e-3, 1.0, 1.0)):
        y = np.array([r[key] for r in rec]) * sc
        a.plot(t * 1e3, y, color=C["dynamic-PP"], lw=2, label="dynamic-PP")
        if key == "lam0":
            a.axhline(lam1[0], color=C["QS-PP"], ls="--", lw=1.2, label="QS-PP (before / after)")
            a.axhline(lam2[0], color=C["QS-PP"], ls="--", lw=1.2)
        else:
            q = {"T": "T", "P": "P", "stall": "stalled_span_fraction"}[key]
            a.plot([-60, 0, 0, t[-1] * 1e3], [r1[q] * sc, r1[q] * sc, r2[q] * sc, r2[q] * sc],
                   color=C["QS-PP"], ls="--", lw=1.2, label="QS-PP")
            a.plot([-60, 0, 0, t[-1] * 1e3], [b1[q] * sc, b1[q] * sc, b2[q] * sc, b2[q] * sc],
                   color=C["baseline"], ls=":", lw=1.5, label="baseline (static, original M2)")
        a.set_xlabel("time since collective step [ms]"); a.set_ylabel(lab); a.grid(alpha=0.3)
        if key == "stall":
            # A zero-stall result should be shown as a non-negative fraction, not
            # autoscaled into a misleading negative y range.
            a.set_ylim(0.0, max(0.05, float(np.nanmax(y)) * 1.1))
    ax[0, 0].legend(fontsize=8)
    fig.suptitle(f"Collective step {c1:.0f}$^\\circ\\to${c2:.0f}$^\\circ$, single rotor, edgewise V={Ve:.0f} m/s, "
                 f"{RPM:.0f} RPM, h={ALTITUDE_M:.0f} m, ISA, zero cyclic", fontsize=10)
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "task11_A1_collective_step.png"), dpi=200); plt.close(fig)

    # --- sweep: step size x edgewise speed
    rows = []
    for Ve_s in RC["edgewise_speeds_for_sweep_ms"]:
        base = flight(BASE_COL, Ve_s)
        lamb, rb = DYN.equilibrium(base)
        for dcol in RC["collective_step_sizes_deg"]:
            fn = flight(BASE_COL + dcol, Ve_s)
            lamn, rn = DYN.equilibrium(fn)
            jump = DYN.loads(fn, lamb)
            lam, t63 = lamb.copy(), float("nan")
            target = lamb[0] + 0.632 * (lamn[0] - lamb[0])
            tt, dt = 0.0, 0.008
            while tt < 0.5:
                lam = DYN.advance(fn, lam, dt); tt += dt
                if (lam[0] - target) * np.sign(lamn[0] - lamb[0]) >= 0 and math.isnan(t63):
                    t63 = tt; break
            rows.append(dict(V_edge_ms=Ve_s, mu=Ve_s / (RPM * 2 * math.pi / 60 * 2.6), dcollective_deg=dcol,
                             T_before_N=rb["T"], T_jump_N=jump["T"], T_qs_after_N=rn["T"],
                             stall_jump=jump["stalled_span_fraction"], stall_qs_after=rn["stalled_span_fraction"],
                             thrust_overshoot_pct=100 * (jump["T"] / rn["T"] - 1.0),
                             P_overshoot_pct=100 * (jump["P"] / rn["P"] - 1.0),
                             t63_inflow_ms=1e3 * t63))
            print(f"   V={Ve_s:4.0f} d={dcol:.1f}: overshoot T {rows[-1]['thrust_overshoot_pct']:5.1f}%  "
                  f"P {rows[-1]['P_overshoot_pct']:5.1f}%  t63 {rows[-1]['t63_inflow_ms']:.0f} ms")
    csv_write("task11_A2_step_speed_sweep.csv", rows)
    fig, ax = plt.subplots(1, 3, figsize=(12, 3.8))
    for Ve_s in RC["edgewise_speeds_for_sweep_ms"]:
        sel = [r for r in rows if r["V_edge_ms"] == Ve_s]
        x = [r["dcollective_deg"] for r in sel]
        ax[0].plot(x, [r["thrust_overshoot_pct"] for r in sel], "o-", label=f"V={Ve_s:.0f} m/s")
        ax[1].plot(x, [r["P_overshoot_pct"] for r in sel], "o-", label=f"V={Ve_s:.0f} m/s")
        ax[2].plot(x, [r["t63_inflow_ms"] for r in sel], "o-", label=f"V={Ve_s:.0f} m/s")
    for a, lab in zip(ax, ("Peak thrust overshoot vs QS [%]", "Peak power overshoot vs QS [%]",
                           "Inflow 63% response time [ms]")):
        a.set_xlabel(r"collective step $\Delta\theta_0$ [deg]"); a.set_ylabel(lab); a.grid(alpha=0.3)
    ax[0].legend(fontsize=8)
    fig.suptitle(f"Dynamic-inflow transient vs step size and edgewise speed (single rotor, {RPM:.0f} RPM, h={ALTITUDE_M:.0f} m, "
                 rf"base $\theta_0$={BASE_COL:.0f}$^\circ$)", fontsize=10)
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "task11_A2_step_speed_sweep.png"), dpi=200); plt.close(fig)


# ----------------------------------------------------------------------------- B
def part_B():
    print("[B] longitudinal cyclic step ...")
    Ve = float(RC["edgewise_speed_for_cyclic_step_ms"])
    step = float(RC["longitudinal_cyclic_final_deg"]) - float(RC["longitudinal_cyclic_initial_deg"])
    f1, f2 = flight(BASE_COL, Ve, th1s=float(RC["longitudinal_cyclic_initial_deg"])), flight(BASE_COL, Ve, th1s=float(RC["longitudinal_cyclic_final_deg"]))
    lam1, r1 = DYN.equilibrium(f1)
    lam2, r2 = DYN.equilibrium(f2)
    b1, b2 = SOLVER.solve(f1), SOLVER.solve(f2)
    rec = march(f2, lam1, float(RC["cyclic_step_duration_s"]), float(RC["cyclic_step_dt_s"]))
    csv_write("task11_B_cyclic_step_timehistory.csv", rec)
    t = np.array([r["t"] for r in rec]) * 1e3
    fig, ax = plt.subplots(2, 2, figsize=(10, 6.5))
    items = (("My", "Hub pitching moment $M_{y,R}$ [N m]"), ("Mx", "Hub rolling moment $M_{x,R}$ [N m]"),
             ("lam_c", r"Longitudinal inflow state $\lambda_c$ [-]"), ("lam_s", r"Lateral inflow state $\lambda_s$ [-]"))
    for a, (key, lab) in zip(ax.flat, items):
        a.plot(t, [r[key] for r in rec], color=C["dynamic-PP"], lw=2, label="dynamic-PP")
        if key in ("Mx", "My"):
            k2 = "M_hub_rotor"; i = 0 if key == "Mx" else 1
            a.plot([-60, 0, 0, t[-1]], [r1[k2][i]] * 2 + [r2[k2][i]] * 2, color=C["QS-PP"], ls="--", label="QS-PP")
            a.plot([-60, 0, 0, t[-1]], [b1[k2][i]] * 2 + [b2[k2][i]] * 2, color=C["baseline"], ls=":", lw=1.5,
                   label="baseline (static)")
        else:
            i = 2 if key == "lam_c" else 1
            a.axhline(lam1[i], color=C["QS-PP"], ls="--", lw=1.0); a.axhline(lam2[i], color=C["QS-PP"], ls="--", lw=1.0,
                                                                                label="QS-PP")
        a.set_xlabel("time since cyclic step [ms]"); a.set_ylabel(lab); a.grid(alpha=0.3)
    ax[0, 0].legend(fontsize=8)
    fig.suptitle(rf"Longitudinal cyclic step $\theta_{{1s}}$ 0$\to${step:.0f}$^\circ$ (rotor frame), V={Ve:.0f} m/s edgewise, "
                 rf"$\theta_0$={BASE_COL:.0f}$^\circ$, {RPM:.0f} RPM, h={ALTITUDE_M:.0f} m", fontsize=10)
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "task11_B_cyclic_step.png"), dpi=200); plt.close(fig)
    My = np.array([r["My"] for r in rec]); Mx = np.array([r["Mx"] for r in rec])
    summ = dict(My_initial=My[0], My_qs_final=r2["M_hub_rotor"][1], My_baseline_final=b2["M_hub_rotor"][1],
                Mx_initial=Mx[0], Mx_qs_final=r2["M_hub_rotor"][0], Mx_baseline_final=b2["M_hub_rotor"][0],
                My_initial_over_qs_pct=100 * (My[0] / r2["M_hub_rotor"][1] - 1.0),
                Mx_initial_over_qs_pct=100 * (Mx[0] / r2["M_hub_rotor"][0] - 1.0),
                Mx_baseline_over_qs_pct=100 * (b2["M_hub_rotor"][0] / r2["M_hub_rotor"][0] - 1.0),
                Mx_change_max_pct_of_My=100 * np.max(np.abs(Mx - r1["M_hub_rotor"][0])) / abs(r2["M_hub_rotor"][1]))
    csv_write("task11_B_cyclic_step_summary.csv", [summ])
    print("   ", {k: round(float(v), 2) for k, v in summ.items()})


# ----------------------------------------------------------------------------- C
def compressed(mission, s):
    m = copy.deepcopy(mission)
    for seg in m["segments"]:
        seg["duration_s"] = seg["duration_s"] / s
        if "climb_rate_ms" in seg:                      # keep altitude change: rate scales with s
            seg["climb_rate_ms"] = seg["climb_rate_ms"] * s
    # Mission histories use a 0.25 s reporting/forcing grid (compressed with
    # the nacelle-rate factor). The dynamic inflow ODE still substeps internally
    # from its eigenvalue-based stability limit.
    m["dt_s"] = float(RC["mission_reporting_dt_s"]) / s
    return m


def part_C(factors=None):
    if factors is None:
        factors = tuple(int(x) for x in RC["conversion_time_compression_factors"])
    print("[C] outbound conversion, mission level ...")
    base = json.load(open(os.path.join(IN, "example_transition_outbound.json")))
    runs = {}
    summary = []
    for s in factors:
        mission = compressed(base, s)
        rate = float(RC["base_nacelle_rate_deg_s"]) * s
        for model, key in (("static", "baseline"), ("pitt_peters_qs", "QS-PP"), ("pitt_peters", "dynamic-PP")):
            # A 10-radial by 8-azimuth grid keeps the full four-rate, three-model mission study
            # reproducible on a laptop while retaining the same model equations.
            res = MissionPlannerV2(radial_stations=int(RC["radial_stations_for_task11_mission"]),
                                  n_azimuth=int(RC["azimuth_stations_for_task11_mission"]), inflow_model=model).run(copy.deepcopy(mission))
            runs[(s, key)] = res
            print(f"   s={s} ({rate:.1f} deg/s) {key:11s} success={res['success']} fuel={res['final_fuel_kg']:.2f}")
            # Save every model history as each rate finishes so long runs are resumable
            # and all three inflow modes can be compared without rerunning the mission.
            csv_write(f"task11_C_history_{key.replace('-', '_')}_s{s}.csv", res["history"])
        h = {k: runs[(s, k)]["history"] for k in C}
        n = min(len(v) for v in h.values())
        P = {k: np.array([r["P_required_kW"] for r in h[k][:n]]) for k in C}
        tt = np.array([r["time_s"] for r in h["dynamic-PP"][:n]])
        sm = {k: np.array([r["stall_margin_pct"] for r in h[k][:n]]) for k in C}
        d = P["dynamic-PP"] - P["QS-PP"]
        summary.append(dict(
            time_compression=s, nacelle_rate_deg_s=rate,
            success_baseline=runs[(s, "baseline")]["success"], success_QS=runs[(s, "QS-PP")]["success"],
            success_dynamic=runs[(s, "dynamic-PP")]["success"],
            Pmax_baseline_kW=P["baseline"].max(), Pmax_QS_kW=P["QS-PP"].max(), Pmax_dynamic_kW=P["dynamic-PP"].max(),
            max_abs_dyn_minus_QS_kW=np.abs(d).max(), max_abs_dyn_minus_QS_pct=100 * np.max(np.abs(d) / P["QS-PP"]),
            t_of_max_diff_s=tt[np.argmax(np.abs(d))],
            fuel_baseline_kg=runs[(s, "baseline")]["final_fuel_kg"], fuel_QS_kg=runs[(s, "QS-PP")]["final_fuel_kg"],
            fuel_dynamic_kg=runs[(s, "dynamic-PP")]["final_fuel_kg"],
            min_stall_margin_QS=sm["QS-PP"].min(), min_stall_margin_dynamic=sm["dynamic-PP"].min()))
        csv_write(f"task11_C_summary_s{s}.csv", [summary[-1]])
    csv_write("task11_C_conversion_summary.csv", summary)

    fig, ax = plt.subplots(2, 2, figsize=(11, 7))
    for j, s in enumerate((factors[0], factors[-1])):
        h = {k: runs[(s, k)]["history"] for k in C}
        n = min(len(v) for v in h.values())
        t = np.array([r["time_s"] for r in h["dynamic-PP"][:n]])
        for k in C:
            ax[0, j].plot(t, [r["P_required_kW"] for r in h[k][:n]], color=C[k], lw=1.6, label=k)
        rate = float(RC["base_nacelle_rate_deg_s"]) * s
        ax[0, j].set_title(f"Power required, nacelle rate {rate:.1f} deg/s")
        ax[0, j].set_xlabel("time [s]"); ax[0, j].set_ylabel("aircraft power required [kW]"); ax[0, j].grid(alpha=0.3)
        ax[0, j].legend(fontsize=8)
    for s in factors:
        h = {k: runs[(s, k)]["history"] for k in ("QS-PP", "dynamic-PP")}
        n = min(len(v) for v in h.values())
        t = np.array([r["time_s"] for r in h["dynamic-PP"][:n]]) * s
        d = np.array([a["P_required_kW"] - b["P_required_kW"] for a, b in zip(h["dynamic-PP"][:n], h["QS-PP"][:n])])
        rate = float(RC["base_nacelle_rate_deg_s"]) * s
        ax[1, 0].plot(t, d, label=f"{rate:.1f} deg/s")
    ax[1, 0].set_xlabel("time x compression [s] (baseline timeline)"); ax[1, 0].set_ylabel("dynamic - QS power [kW]")
    ax[1, 0].legend(fontsize=8); ax[1, 0].grid(alpha=0.3)
    ax[1, 1].plot([r["nacelle_rate_deg_s"] for r in summary], [r["max_abs_dyn_minus_QS_kW"] for r in summary], "o-")
    ax[1, 1].set_xlabel("nacelle rate [deg/s]"); ax[1, 1].set_ylabel("max |dynamic - QS| power [kW]"); ax[1, 1].grid(alpha=0.3)
    fig.suptitle(f"Outbound hover-to-airplane conversion (M2 scheduled controls, h={ALTITUDE_M:.0f} m, "
                 f"{AIRCRAFT.gross_weight_kg:.0f} kg): inflow-model effect on power",
                 fontsize=10)
    fig.tight_layout()
    plot_name = "task11_C_conversion.png" if len(factors) > 1 else f"task11_C_conversion_s{factors[0]}.png"
    fig.savefig(os.path.join(FIG, plot_name), dpi=200); plt.close(fig)


if __name__ == "__main__":
    parts = [a.upper() for a in sys.argv[1:]] or ["A", "B", "C"]
    for p in parts:
        if p == "A":
            part_A()
        elif p == "B":
            part_B()
        elif p == "C":
            part_C()
        elif p in {"C1", "C2", "C4", "C8"}:
            # Run a single rate if the full four-rate study is too long for one session.
            part_C((int(p[1:]),))
        else:
            raise SystemExit(f"Unknown task selector {p!r}; choose A, B, C, C1, C2, C4 or C8")
