# Task 11 conversion-rate summary inputs

The `summary_s1.csv`, `summary_s2.csv`, `summary_s4.csv`, and `summary_s8.csv` files are compact, one-row-per-case snapshots of the coupled MissionPlannerV2 results for conversion time-compression factors 1, 2, 4, and 8. These correspond to nominal nacelle rates of 3.75, 7.5, 15, and 30 degrees per second. Each result compares the original M2 static inflow, quasi-steady Pitt–Peters, and time-integrated Pitt–Peters modes.

Each of the twelve mode/rate time-history CSV files is saved under `outputs/`. The plotting script `task11_conversion_summary.py` prefers the latest per-rate summaries in `outputs/` and falls back to these snapshots if a case has not been rerun. To recompute a single case, run `python task11_dynamic_inflow_assessment.py C1`, `C2`, `C4`, or `C8`; then run `python task11_conversion_summary.py` to rebuild combined tables/plots.

The mission schedules are time-compressed for a controlled sensitivity comparison. Do not interpret cross-rate fuel-burn differences as operational fuel-saving predictions. All reported success flags are outputs of the current low-order model and its constraints, not experimental certification.
