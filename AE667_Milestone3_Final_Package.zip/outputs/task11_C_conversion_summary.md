# Task 11 conversion-rate assessment summary

This table combines the per-rate results computed by `MissionPlannerV2` for the three inflow modes.
The run configuration is a sensitivity study using compressed mission schedules; these are not operational recommendations.
The full rerun command is `python task11_dynamic_inflow_assessment.py C`. The summary plot is reproduced by `python task11_conversion_summary.py`.

| Nacelle rate (deg/s) | All modes succeeded? | Peak power baseline (kW) | Peak power QS (kW) | Peak power dynamic (kW) | max |ΔP| dynamic−QS (kW) | dynamic fuel burned (kg) | min stall margin dynamic (pp) |
|---:|:---:|---:|---:|---:|---:|---:|---:|
| 3.75 | Yes | 742.21 | 755.41 | 755.20 | 4.65 | 2.435 | 15.0 |
| 7.50 | Yes | 742.21 | 755.41 | 755.20 | 4.65 | 1.217 | 15.0 |
| 15.00 | Yes | 742.21 | 755.41 | 755.19 | 4.70 | 0.609 | 15.0 |
| 30.00 | Yes | 742.21 | 755.41 | 755.15 | 5.18 | 0.304 | 15.0 |

## Interpretation

Across these computed cases the dynamic and quasi-steady Pitt–Peters predictions are close but not identical. The largest reported power difference is only a few kW (roughly 1.4–1.6% of the QS power at the time of maximum difference), while the static M2 baseline differs from both Pitt–Peters modes because it uses a different inflow model. The very similar minimum stall margins in this set are driven by the low-order M2 margin/flagging logic; they should not be interpreted as high-fidelity rotor-stall certification.

## Provenance and limitation

The inputs are the saved single-row summaries in `data/dynamic_inflow_conversion_summaries/`. Those rows were produced by separate `MissionPlannerV2` runs for each rate and inflow model. The combined figure is a plot of those computed summaries. Analytical hover verification does not replace direct validation against measured forward-flight/transient inflow data.
