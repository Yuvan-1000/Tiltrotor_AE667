# Dynamic-inflow analytical verification

## Scope
The uniform hover state is checked against the exact solution of the model's nonlinear hover ODE. This is an analytical code-verification benchmark, not experimental validation of Pitt–Peters against a physical rotor.

## Case
- RPM: 750.0
- Thrust coefficient step: 0.00300 → 0.00450
- Time step: 0.0010 s; duration: 0.500 s
- Published apparent-mass constants used: M0 = 128/(75π) = 0.543248872; M1 = 64/(45π) = 0.452707394

## Result
- Maximum absolute error in λ₀ over the complete time history: 1.187193e-11
- Maximum relative error over the complete time history: 2.664091e-08%

## Time-step convergence
| dt (s) | Steps | Absolute end-state error | Observed order |
|---:|---:|---:|---:|
| 0.0080 | 62 | 1.231901e-09 | — |
| 0.0040 | 125 | 1.859624e-13 | 12.694 |
| 0.0020 | 250 | 1.109529e-14 | 4.067 |
| 0.0010 | 500 | 6.730727e-16 | 4.043 |

## Interpretation and limitation
The numerical solution should converge to the analytical trajectory and final momentum-theory value. This verifies integration of the stated hover-mode equation and its time-step behaviour. It does not, by itself, verify all forward-flight influence-matrix constants, moment normalisations, or physical prediction accuracy; published experimental validation remains a distinct step.
