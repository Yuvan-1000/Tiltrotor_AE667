# Published-aircraft comparison notes

Reference aircraft: Bell Boeing V-22 Osprey. Values are read from `inputs/reference_aircraft_v22.json`. Rotor disk loading, installed power per gross mass, and speed are useful scale indicators, not proof of equivalent mission capability. Payload fraction is only indicative because the V-22 number is the single external cargo-hook load, whereas the project aircraft number is an internal payload allowance. Wing loading is omitted because a consistent wing reference area was not available in the selected manufacturer specifications.

Project rotor disk loading: 692.7 N/m²; V-22: 1107.0 N/m².
Project installed power: 266.7 kW/t; V-22: 384.4 kW/t.
Project demonstrated cruise: 77.8 kt; V-22 published maximum cruise: 266.0 kt.
