# Milestone 3 Final Performance and Mission Summary

## Frozen configuration
MTOW 3000 kg = 1950 kg empty + 550 kg payload + 500 kg fuel.
Twin rotors: R=2.60 m, B=3, chord root=0.34 m, taper=0.80, twist 0.0 to -12.0 deg.
Wing: S=60.0 m2, span=12.0 m, AR=2.40.

## Hover (M1 axial BEMT, MTOW, sea level ISA)
Collective 23.48 deg at 750 RPM; thrust per rotor 14710 N; per-rotor aerodynamic power 327.0 kW.
Total shaft power 688.4 kW vs 800.0 kW available; margin 111.6 kW; FM=0.756.
M1 reference: maximum hover gross weight 3,205 kg at sea level; OGE hover ceiling at MTOW 820 m.

## Airplane-mode cruise (re-trimmed, M2 model, 500 m ISA)
V=40.0 m/s (77.8 kt), RPM=650, collective=31.50 deg, pitch=3.58 deg.
Power required 498.2 kW vs 762.3 kW available; margin 264.1 kW (34.6%).
Estimated aircraft L/D=5.75; propulsive efficiency estimate=0.44; trim max scaled residual=2.57e-06.

## End-to-end mission
Success: True; time 52.07 min; cumulative path distance 106.48 km (100.0 km level cruise leg).
Fuel 500.0 -> 364.7 kg; burned 135.3 kg; reserve 50.0 kg; landing gross mass 2864.7 kg.
Peak power 738.3 kW; minimum power margin 3.15%.
Maximum predicted stalled span 13.75% (M2 warning threshold 5.0%, hard rejection threshold 25.0%); minimum margin to hard limit 11.25 percentage points; minimum tip-Mach margin 0.0755.
Limiting point: outbound_conversion_01 at t=4.32 min, V=10.0 m/s, gamma=75.0 deg.

## Interpretation and validity
Mission Planner v2 is a scheduled, low-order state/mass/fuel feasibility simulation. It is not a 6-DOF flight-dynamics or closed-loop pilot-control simulation. Conversion waypoints are reused from M2; the airplane-mode cruise point is explicitly trimmed and enforced.
The primary M3 mission uses the M2 static Glauert/Drees inflow model for direct comparability. The optional three-state Pitt-Peters extension is retained as a separate, non-primary analysis and is not used for the graded M3 mission.
