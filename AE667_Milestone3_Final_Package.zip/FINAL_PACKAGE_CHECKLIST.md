# Milestone 3 Final Code Package — Delivery Checklist

This archive contains the final M1/M2-derived tiltrotor analysis code and the M3 final-design / end-to-end mission workflow. The presentation deck is intentionally not included; the team will populate its supplied template separately.

## Required deliverables

- [x] Modular M1 axial BEMT, M2 edgewise rotor, aircraft, trim and Mission Planner v2 modules.
- [x] Frozen final aircraft configuration in `inputs/aircraft_config.json`.
- [x] Editable final mission settings in `inputs/m3_mission_settings.json`.
- [x] M2 outbound/inbound conversion waypoint inputs reused by the final mission.
- [x] V-22 published-reference data and source URLs in `inputs/reference_aircraft_v22.json`.
- [x] Final generated mission definition in `inputs/mission_final.json`.
- [x] M3 time-history, segment summary, performance summary, design comparison and requirement-compliance outputs.
- [x] Nine M3 summary / mission figures and the retained M1/M2 figures.
- [x] README, references, acknowledgement, dependency files and audit scripts.
- [x] Automated regression/smoke tests.

## Reproduction commands

From this directory:

```bash
python -m pip install -r requirements.txt
python -m pip install -r requirements-dev.txt
python package_audit.py
python -m pytest -q
python run_m3_final.py
python m3_package_audit.py
```

`run_m3_final.py` regenerates the final mission input and M3 outputs/figures. `m3_package_audit.py` then reconciles the mission history with summary metrics and checks reserve, power, rotor limits, mass closure and required files/figures. The M1/M2 regression/smoke suite is expected to pass before and after the M3 run.

## Final run evidence

The included generated run uses 1 s mission time steps and an 80 radial × 12 azimuth mission grid, 500 m ISA cruise altitude, zero wind, a 100 km level-cruise leg at 40 m/s, and the M2 conversion waypoint sequences. The mission result is a low-order scheduled feasibility analysis, not a 6-DOF closed-loop flight simulation.

The M3 analysis identifies a power-limited outbound conversion waypoint and reports the stalled-span warning exceedance separately from the M2 hard rejection screen. It also marks the original 110 m/s cruise target, 550 km design-range demonstration and 6,000 m service-ceiling target as not achieved or not demonstrated where appropriate. Consult `README.md`, `outputs/m3_final_summary.md` and `outputs/m3_requirement_compliance.csv` for the complete interpretation.

## Important validity boundary

Passing tests and matching the Milestone 1/2 regression baselines establish software verification/compatibility. They do not establish experimental validation of all physical models. The optional three-state dynamic-inflow extension is retained for context but is not used in the primary M3 mission result.
